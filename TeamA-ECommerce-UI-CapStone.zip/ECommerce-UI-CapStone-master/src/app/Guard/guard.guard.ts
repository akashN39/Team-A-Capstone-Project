import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthServiceService } from '../Services/auth-service.service';

@Injectable({
  providedIn: 'root'
})
export class GuardGuard implements CanActivate {
  constructor(
    private authService: AuthServiceService,
    private router: Router
  ) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
      const expectedRoles = next.data['expectedRoles'];
      const userRole = this.authService.getRole();

      if (this.authService.isloggedin() && expectedRoles.includes(userRole)) {
        return true;
      } else {
        this.router.navigate(['/unauthorized']);
        return false;
      }
  }
}
