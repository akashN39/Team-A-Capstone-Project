import { HttpClient, HttpClientJsonpModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class ShippingService {

  baseUrl="https://localhost:7037/api/Shipping"
  constructor(private http:HttpClient) { }

  getShipping(): Observable<any> {
    return this.http.get<any>(this.baseUrl);
  }
  createShipping(orderId: number) {
    const url = `${this.baseUrl}/create-shipping/${orderId}`;
    return this.http.post<any>(url, {});
  }
}
