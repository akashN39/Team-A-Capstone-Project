import { Injectable } from '@angular/core';
import { from } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environment';
import { createApi } from 'unsplash-js';
import { ApiResponse } from 'unsplash-js/dist/helpers/response';
import { Random } from 'unsplash-js/dist/methods/photos/types';

@Injectable({
  providedIn: 'root'
})
export class UnsplashService {
  private unsplashApi;

  constructor() {
    this.unsplashApi = createApi({
      accessKey: environment.unsplashAccessKey,
    });
  }
  public getRandomImage(): Observable<Partial<ApiResponse<Random>>> {
    return from(
      this.unsplashApi.photos.getRandom(undefined, undefined)
    ) as Observable<ApiResponse<Random>>;
  }

  
}
