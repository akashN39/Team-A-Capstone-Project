import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Observable } from 'rxjs/internal/Observable';
import { Cart } from '../Models/cart.model';
import { AuthServiceService } from './auth-service.service';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class CartService {


  baseUrl = "https://localhost:7037/api/Cart"
  constructor(private http: HttpClient,private user:AuthServiceService) { }
  userId = this.user.getCode();
  addToCart(productId: number, quantity: number): Observable<Cart> {
    //  userId = this.user.getCode();
    const url = `${this.baseUrl}/${this.userId}`;
    const body = {
      productId: productId,
      quantity: quantity
    };
    return this.http.post<Cart>(url, body);
  }


  getCartByUserId(): Observable<any> {
   
    return this.http.get(`${this.baseUrl}/${this.userId}`);
  }

  deleteCartItem( productId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${this.userId}/${productId}`);
  }

}
