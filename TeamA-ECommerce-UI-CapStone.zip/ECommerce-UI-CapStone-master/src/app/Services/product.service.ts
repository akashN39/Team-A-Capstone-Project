import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Cart } from '../Models/cart.model';
import { Product } from '../Models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  baseUrl = "https://localhost:7037/api"
  constructor(private http: HttpClient) { }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.baseUrl + '/Product');
  }

  addToCart(userId: number, productId: number, quantity: number): Observable<Cart> {
    const url = `${this.baseUrl}/Cart/${userId}`;
    const body = {
      productId: productId,
      quantity: quantity
    };
    return this.http.post<Cart>(url, body);
  }

  getProductById(id: number): Observable<any> {
    return this.http.get<any>(this.baseUrl + '/Product/' + id);
  }

  updateProduct(id: number, productRequest: Product): Observable<Product> {
    return this.http.put<Product>(this.baseUrl + '/Product/' + id, productRequest)
  }
  deleteProduct(id: number): Observable<Product> {
    return this.http.delete<Product>(this.baseUrl + '/Product/' + id)
  }

  addProduct(productRequest:Product):Observable<Product>{
    return this.http.post<Product>(this.baseUrl+'/Product/',productRequest)
  }

  uploadProductsFile(file: File) {
    const formData = new FormData();
    formData.append('file', file, file.name);
    return this.http.post<any>(`${this.baseUrl}/Product/upload`, formData);
  }

  uploadImage(productId: number, file: File): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('profileImage', file, file.name);
    return this.http.post('https://localhost:7037/' + productId + '/upload-image', formData);
  }
  //path
  getImagePath(relativePath:string){
    return ('https://localhost:7037/${relativePath}');
  }
  }

