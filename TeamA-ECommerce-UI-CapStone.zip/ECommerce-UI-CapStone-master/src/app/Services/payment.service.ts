import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  baseUrl = "https://localhost:7037/api"
  constructor(private http: HttpClient) { }

  submitPayment(orderId: number, paymentData: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/Payment/${orderId}`, paymentData);
  }
}
