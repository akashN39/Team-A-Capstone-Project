import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { UserFetch } from '../Dto/userFetch.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseUrl="https://localhost:7037/api/User"
  constructor(private http:HttpClient) { }
  getUsers(): Observable<UserFetch[]> {
    return this.http.get<UserFetch[]>(this.baseUrl);
  }
  getUserById(id: number): Observable<UserFetch> {
    return this.http.get<UserFetch>(`${this.baseUrl}/${id}`);
  }
  updateUser(user: UserFetch): Observable<any> {
    return this.http.put(`${this.baseUrl}/${user.Id}`, user);
  }

    deleteUser(userId: number): Observable<any> {
      const url = `${this.baseUrl}/${userId}`;
      return this.http.delete(url);
    }
  }

