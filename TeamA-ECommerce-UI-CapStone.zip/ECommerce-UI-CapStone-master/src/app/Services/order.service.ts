import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { throwError } from 'rxjs/internal/observable/throwError';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Order } from '../Models/order.model';
import { AuthServiceService } from './auth-service.service';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  baseUrl = "https://localhost:7037/api"
  constructor(private http: HttpClient, private user: AuthServiceService) { }
  userId = this.user.getCode();
  getOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(this.baseUrl + '/Order');
  }

  getOrderById(orderId: number): Observable<Order> {
    return this.http.get<Order>(`${this.baseUrl}/Order/${orderId}`);
  }
  placeOrderForUser() {
    return this.http.post<any>(`${this.baseUrl}/Order/${this.userId}`, {});
  }

  getOrdersByUserId(): Observable<Order[]> {
    const url = `${this.baseUrl}/Order/getOrders/${this.userId}`;
    return this.http.get<Order[]>(url).pipe(
      catchError((error: HttpErrorResponse) => {
        return throwError(error.message || 'Server error');

      })
    );
  }

  deleteOrderById(orderId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/Order/${orderId}`);
  }




}
