import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NotifyService } from 'src/app/notify.service';
import { OrderService } from 'src/app/Services/order.service';

@Component({
  selector: 'app-user-order',
  templateUrl: './user-order.component.html',
  styleUrls: ['./user-order.component.scss'],
})
export class UserOrderComponent {
  orders:any;
  noOrders:boolean=true
  constructor(private ordersService: OrderService,
    private notify:NotifyService,private router:Router,private activatedRoute: ActivatedRoute) {
   }

  ngOnInit(): void {
        this.getOrdersByUserId();
  }

  getOrdersByUserId(): void {
    this.ordersService.getOrdersByUserId()
      .subscribe((orders: any) => this.orders = orders);
  }

  deleteOrder(orderId: number) {
    this.ordersService.deleteOrderById(orderId)
      .subscribe(data => {
       this.notify.showSuccess("Order Item Removed Successfully!",2000);
        this.getOrdersByUserId();
      }, error => console.log(error));
  }
}
