import { Component, HostListener, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { NotifyService } from 'src/app/notify.service';
import { CartService } from 'src/app/Services/cart.service';
import { OrderService } from 'src/app/Services/order.service';

@Component({
  selector: 'app-user-cart',
  templateUrl: './user-cart.component.html',
  styleUrls: ['./user-cart.component.scss']
})
export class UserCartComponent {


  cart: any;
  constructor(private cartService: CartService, 
    private notify:NotifyService,private router: Router,private orderService:OrderService) {
  }
  ngOnInit() {

    this.cartService.getCartByUserId().subscribe(cart => {
      this.cart = cart;
    });
  }
  placeOrder() {
    this.orderService.placeOrderForUser().subscribe(response => {
      // console.log(response.message);
      // console.log(response.orderId);
      this.notify.showSuccess("Items  Added to  Orders!")
      this.router.navigate(['/user-order']);
    });
  }
deleteCartItem(productId: number) {
  this.cartService.deleteCartItem(productId).subscribe(
    response => {
     this.notify.showInfo('CartItem Cleared successfully',2000);
      // Refresh cart data
      this.cartService.getCartByUserId().subscribe(cart => {
        this.cart = cart;
      });
    },
    error => {  
      this.notify.showError("Error While removing Cart",1600)
      // console.log('Error while deleting cart item:', error);
      // Add code to show error message
    }
  );
}

}
