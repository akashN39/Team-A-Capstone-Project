import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NotifyService } from 'src/app/notify.service';
import { PaymentService } from 'src/app/Services/payment.service';

@Component({
  selector: 'app-user-pay',
  templateUrl: './user-pay.component.html',
  styleUrls: ['./user-pay.component.scss']
})
export class UserPayComponent {
  orderId!: number;
  paymentModel = {
    cardNumber: '',
    cardHolderName: '',
    expirationMonth: 0,
    expirationYear: 0,
    cvv: ''
  };

  paymentDone = false; // payment status property

  successMessage!: string;
  errorMessage!: string;
  successboard:Boolean=false;
  constructor(
    private route: ActivatedRoute,
    private paymentService: PaymentService,
    private notify:NotifyService,
    private router:Router
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.orderId = params['id'];
    });
  }

  onSubmit() {
  
    this.paymentService.submitPayment(this.orderId, this.paymentModel).subscribe(response => {
      this.notify.showSuccess("Payment Successfully Done!",1200)
      // console.log(response.message);
      this.successboard=true
      this.router.navigateByUrl("/user-order");
      // Redirect to payment success page
    }, error => {
      console.log(error);
      this.notify.showError("Server Error..Please try again later!")
      // Show payment error message
    });
  }
}
