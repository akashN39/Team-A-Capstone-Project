import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { CartService } from 'src/app/Services/cart.service';
import { NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  isLoggedIn: boolean = false;
  isUser: boolean = false;
  isAdmin: boolean = false;

  constructor(private authService: AuthServiceService, private router: Router) {
    router.events.subscribe((val) => {
      if (val instanceof NavigationEnd) {
        const role = this.authService.getRole();
        console.log(role);
        if (role) {
          console.log("User role is:", role);
          this.isLoggedIn = true;
          if (role === 'User') {
            this.isUser = true;
          } else if (role === 'Admin') {
            this.isAdmin = true;
          }
        }
      }
    });
  }

  ngOnInit(): void {
    const role = this.authService.getRole();
    console.log(role);
    if (role) {
      console.log("User role is:", role);
      this.isLoggedIn = true;
      if (role === 'User') {
        this.isUser = true;
      } else if (role === 'Admin') {
        this.isAdmin = true;
      }
    }
  }

  logOut(): void {
    localStorage.clear();
    this.router.navigateByUrl('/login')
    this.isLoggedIn = false;
    this.isUser = false;
    this.isAdmin = false;
  }
}
