import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from 'src/app/Models/product.model';
import { CartService } from 'src/app/Services/cart.service';
import { ProductService } from 'src/app/Services/product.service';
@Component({
  selector: 'app-user-product-view',
  templateUrl: './user-product-view.component.html',
  styleUrls: ['./user-product-view.component.scss']
})
export class UserProductViewComponent {


  products: Product[] = [];
  product = {
    productQuantity: 0
  };
  constructor(private productService: ProductService,private cartService: CartService,
    private router:Router) {
      this.product.productQuantity = 0;
     }

  ngOnInit(): void {
    this.productService.getProducts().subscribe(products => {
      this.products = products;
    });
  }
  addToCart(productId: number, quantity: number): void {
    this.cartService.addToCart(productId, quantity).subscribe(
      response => {
        console.log(response.message); // or show a success message to user
        this.router.navigateByUrl('user-cart')
      },
      error => {
        console.log(error); // or show an error message to user
      }
    );
  }

  decreaseQuantity(product: Product) {
    if (product.productQuantity > 1) {
      product.productQuantity--;
    }
  }
  
  increaseQuantity(product: Product) {
    if (product.productQuantity < 10) {
      product.productQuantity++;
    }
  }
}
