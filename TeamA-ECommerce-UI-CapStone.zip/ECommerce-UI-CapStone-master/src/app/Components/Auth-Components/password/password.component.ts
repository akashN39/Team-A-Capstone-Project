import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { NotifyService } from 'src/app/notify.service';
import { AuthServiceService } from 'src/app/Services/auth-service.service';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.scss']
})
export class PasswordComponent {
  //FOR-FORGOT-PASSWORD
  email: string = '';
  message: string = '';
  //FOR-RESET-PASSWORD
  token: string = '';
  password: string = '';
  confirmPassword: string = '';
  errorMessage: string=''; // define the errorMessage property
  showResetForm:boolean=false;
  constructor(private userService: AuthServiceService,
    private router:Router,   private snackbar: MatSnackBar,private notify:NotifyService) { }

  onSubmit(): void {
    this.userService.forgotPassword(this.email).subscribe(
      response => {
        this.notify.showInfo("otp has been sent to your email!",6000)
        // this.snackbar.open('Otp Has been sent to your Email!', undefined, {
        //   duration: 2400
        // })
        console.log(response)
        this.message = response.message;
        this.showResetForm=true;
      },
      error => {
        // this.snackbar.open('Email Not Registered! ', undefined, {
        //   duration: 2000
        // })
        this.notify.showError("Invalid Token",6000)
        this.message = error.error.message;

      }
    );
  }

  onReset(): void {
    this.userService.resetPassword(this.token, this.password, this.confirmPassword)
      .subscribe(response => {
        this.snackbar.open('Password Reset Successful!', undefined, {
          duration: 2400
        })
        setTimeout(() => {
          this.router.navigateByUrl('/login')
        }, 2000);

      }, error => {
        this.snackbar.open('Password Reset Failed..Please Check Details! ', undefined, {
          duration: 2000
        })

      });
  }
}
