import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { UserRegister } from 'src/app/Models/userRegister.model';
import { NotifyService } from 'src/app/notify.service';
import { AuthServiceService } from 'src/app/Services/auth-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  //   user: UserRegister ={
  //     userName: "",
  //     email: "",
  //     password: "",
  //     confirmPassword: "",
  //     city: "",
  //     address: ""
  //   }
  //   error:string=""
  //   registering = false;

  //   constructor(private authService: AuthServiceService, private router: Router,
  //     private snackbar: MatSnackBar) { }

  //   ngOnInit(): void {
  //   }

  //   onSubmit(): void {
  //     this.registering = true;
  //     this.authService.register(this.user)
  //       .subscribe(
  //         response => {
  //           this.snackbar.open('User Registered Successfully!', undefined, {
  //             duration: 2400
  //           })
  //           setTimeout(() => {
  //             this.router.navigateByUrl('/login')
  //           }, 2000);
  //           console.log(response);

  //         },
  //         error => {
  //           // console.error(error);
  //           // this.error = error.error;
  //           this.registering = false;
  //         }
  //       );
  //   }
  // }

  user: UserRegister = {
    userName: '',
    email: '',
    password: '',
    confirmPassword: '',
    city: '',
    address: ''
  };
  error = '';
  registering = false;
  registerForm: FormGroup;

  constructor(private authService: AuthServiceService, private router: Router,
    private notify:NotifyService,private fb: FormBuilder) {
    this.registerForm = this.fb.group({
      userName: ['', [Validators.required, Validators.minLength(4)]],
      email: ['', [Validators.required, Validators.email, Validators.minLength(8)]],
      password: ['', [Validators.required, Validators.minLength(5)]],
      confirmPassword: ['', [Validators.required]],
      city: ['', [Validators.required, Validators.minLength(3)]],
      address: ['', [Validators.required]]
    }, { validator: this.passwordMatchValidator });
  }

  ngOnInit(): void {
  }

  onSubmit(): void {
    this.registering = true;
    this.authService.register(this.registerForm.value)
      .subscribe(
        response => {
          // console.log(response)
          this.notify.showSuccess('User Registered Successfully!', 2000);
          setTimeout(() => {
            this.router.navigateByUrl('/login');
          }, 2000);
          // console.log(response);

        },
        error => {
         this.notify.showWarning("Registration Failed Please Check Validation!",2200)
          this.registering = false;
        }
      );
  }

  passwordMatchValidator(formGroup: FormGroup) {
    const password = formGroup.get('password');
    const confirmPassword = formGroup.get('confirmPassword');
    if (password && confirmPassword) {
      if (password.value !== confirmPassword.value) {
        confirmPassword.setErrors({ mismatch: true });
      } else {
        confirmPassword.setErrors(null);
      }
    }
  }
}
