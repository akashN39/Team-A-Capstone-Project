import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { UserLogin } from 'src/app/Models/userLogin.model';
import { NotifyService } from 'src/app/notify.service';
import { AuthServiceService } from 'src/app/Services/auth-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  user: UserLogin = {
    email: '',
    password: ''
  };

  loginForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthServiceService,
    private router: Router,
    private snackbar:MatSnackBar,
    private notify:NotifyService
  ) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email, Validators.minLength(8)]],
      password: ['', [Validators.required, Validators.minLength(5)]]
    });
  }

  login(): void {
    if (this.loginForm.invalid) {
      return;
    }
    const email = this.loginForm.get('email')?.value;
    const password = this.loginForm.get('password')?.value;

    this.authService.login(email, password).subscribe(
      (data: any) => {
        // console.log(data);
        this.authService.setToken(data.AccessToken);
        this.authService.setCode(data.Code);
        this.authService.setRole(data.UserRole); // Check if setRole() is being called correctly
        // this.snackbar.open('Login Successful!', undefined, {
        //   duration: 1600,
        //   panelClass: ['snackbar-top']
        // });
        this.notify.showSuccess("Login Successful!",2000);
        setTimeout(() => {
          this.router.navigateByUrl('/home');
        }, 1200);

      },
      (error) => {
        this.notify.showError("Login Failed!",2300)
      }
    );
  }
}
