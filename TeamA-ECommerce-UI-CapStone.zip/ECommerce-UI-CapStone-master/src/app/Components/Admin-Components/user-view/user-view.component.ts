import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { UserFetch } from 'src/app/Dto/userFetch.model';
import { UserService } from 'src/app/Services/user.service';

@Component({
  selector: 'app-user-view',
  templateUrl: './user-view.component.html',
  styleUrls: ['./user-view.component.scss']
})
export class UserViewComponent {
  users: UserFetch[]=[];
  displayedColumns: string[] = [ 'UserName', 'Email', 'City', 'Address', 'Role', 'edit'];
  constructor(private userService: UserService,private router:Router) {}
  ngOnInit() {
    this.userService.getUsers().subscribe(
      (users: UserFetch[]) => {
        this.users = users;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  editUser(id: number) {
    this.router.navigate(['edit-user', id]);
  }

  onDeleteUser(userId: number) {
    this.userService.deleteUser(userId).subscribe(() => {
      console.log('User deleted successfully!');
    });
  }
}

