import { Component, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { UserFetch } from 'src/app/Dto/userFetch.model';
import { UserService } from 'src/app/Services/user.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.scss']
})
export class UpdateUserComponent {
  userForm!: FormGroup;
  userId!: number;

  constructor(
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.userForm = this.formBuilder.group({
      UserName: ['', Validators.required],
      Email: ['', [Validators.required, Validators.email]],
      City: [''],
      Address: [''],
      Role: ['']
    });
  }

  ngOnInit() {
    this.userId = +this.route.snapshot.params['id'];
    this.userService.getUserById(this.userId).subscribe(
      (user: UserFetch) => {
        this.userForm.setValue({
          UserName: user.UserName,
          Email: user.Email,
          City: user.City,
          Address: user.Address,
          Role: user.Role
        });
      },
      (error) => {
        console.log(error);
      }
    );
  }

  onSubmit() {
    if (this.userForm.valid) {
      const updatedUser: UserFetch = {
        Id: this.userId,
        UserName: this.userForm.value.UserName,
        Email: this.userForm.value.Email,
        City: this.userForm.value.City,
        Address: this.userForm.value.Address,
        Role: this.userForm.value.Role ? 'Admin' : 'User' // map toggle value to string value
      };

      this.userService.updateUser(updatedUser).subscribe(
        () => {
          this.router.navigate(['/users']);
        },
        (error) => {
          console.log(error);
        }
      );
    }
  }
}


