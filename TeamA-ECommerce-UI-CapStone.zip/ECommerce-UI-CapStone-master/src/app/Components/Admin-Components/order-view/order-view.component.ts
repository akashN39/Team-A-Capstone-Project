import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Order } from 'src/app/Models/order.model';
import { OrderService } from 'src/app/Services/order.service';
import { MatSort } from '@angular/material/sort';
import { ShippingService } from 'src/app/Services/shipping.service';
@Component({
  selector: 'app-order-view',
  templateUrl: './order-view.component.html',
  styleUrls: ['./order-view.component.scss']
})
export class OrderViewComponent {
  displayedColumns: string[] = ['orderId', 'userName', 'email', 'city', 'deliveryAddress', 'orderDate', 'totalAmount', 'action','shipmentDone'];
  dataSource!: MatTableDataSource<Order>;
  constructor(private orderService: OrderService,private shipping:ShippingService) { }
  //for-pagination
  @ViewChild(MatPaginator) matPaginator!: MatPaginator;

  //for-sorting
  @ViewChild(MatSort) matSort!: MatSort;
  filterString = '';

  orderId:any
  shippingResult: any;
  errorMessage:any

  ngOnInit(): void {
    this.orderService.getOrders().subscribe(data => {
      console.log(data)
      this.dataSource = new MatTableDataSource(data);
      //for-pagination
      if (this.matPaginator) {
        this.dataSource.paginator = this.matPaginator;
      }
      //for-sorting
      if (this.matSort) {
        this.dataSource.sort = this.matSort;
      }

    });
  }
  filterOrders() {
    this.dataSource.filter = this.filterString.trim().toLowerCase();
  }

  //for-shipping-buttons
  onCreateShipping(element: Order) {
    this.shipping.createShipping(element.orderId).subscribe(
      (data) => {
        console.log(data);
        element.shipmentDone = true;
      },
      (error) => {
        this.shippingResult = null;
        this.errorMessage = error.error.message;
      }
    );
  }
}
