import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Shipment } from 'src/app/Models/shipment.model';
import { ShippingService } from 'src/app/Services/shipping.service';

@Component({
  selector: 'app-ship-view',
  templateUrl: './ship-view.component.html',
  styleUrls: ['./ship-view.component.scss']
})
export class ShipViewComponent {
  dataSource!: MatTableDataSource<Shipment>;
  displayedColumns: string[] = [
    'orderCreatedAt',
    'customerName',
    'customerEmail',
    'shippingAddress',
    'shippingCity',
    'paymentSuccessful',
    'trackingNumber',
    'deliveryStatus',
    'shippingCreatedAt'
  ];

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;
  constructor(private shipping: ShippingService) { }

  ngOnInit(): void {
    this.shipping.getShipping()
      .subscribe(data => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }
}
