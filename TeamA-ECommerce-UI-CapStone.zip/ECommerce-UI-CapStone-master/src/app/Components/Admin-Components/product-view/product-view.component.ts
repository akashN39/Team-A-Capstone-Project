import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/app/Models/product.model';
import { ProductService } from 'src/app/Services/product.service';

@Component({
  selector: 'app-product-view',
  templateUrl: './product-view.component.html',
  styleUrls: ['./product-view.component.scss']
})
export class ProductViewComponent {
  //required for GET-ALL ONLY
  products: Product[] = [];

  //for-mat-table
  displayedColumns: string[] = ['productImage', 'productName', 'productDescription', 'Category', 'productPrice', 'productQuantity', 'edit'];
  dataSource: MatTableDataSource<Product> = new MatTableDataSource<Product>();

  //for-pagination
  @ViewChild(MatPaginator) matPaginator!: MatPaginator;

  //for-sorting
  @ViewChild(MatSort) matSort!: MatSort;

  //for-filtering
  filterString = ''

  selectedFile?: File;
  message: string = '';




  constructor(private productService: ProductService,
    private router: Router, private snackbar: MatSnackBar) { }

  ngOnInit(): void {
    this.productService.getProducts().subscribe(
      (data) => {
        console.log(data);
        this.products = data;
        this.dataSource = new MatTableDataSource<Product>(this.products);


        //for-pagination
        if (this.matPaginator) {
          this.dataSource.paginator = this.matPaginator;
        }
        //for-sorting
        if (this.matSort) {
          this.dataSource.sort = this.matSort;
        }
      }
    )
  }
  //for search
  filterProducts() {
    this.dataSource.filter = this.filterString.trim().toLowerCase();
  }


  //FOR-CSV-UPLOAD

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0] as File;
  }

  onUpload() {
    if (!this.selectedFile) {
      this.message = 'No file selected.';
      return;
    }

    if (this.selectedFile.type !== 'text/csv') {
      this.message = 'Invalid file type.';
      return;
    }

    this.productService.uploadProductsFile(this.selectedFile).subscribe(
      response => {
        this.message = `${response.message}`;
      },
      error => {
        console.log(error);
        this.message = 'An error occurred.';
      }
    );
  }
  //for-delete
  onDelete(id: any): void {
    this.productService.deleteProduct(id).
      subscribe(
        () =>
          this.snackbar.open("Deleted Successfully!", undefined, { duration: 2000 }))
    setTimeout(() => {   //timeout and move to that url (home page)
      this.router.navigateByUrl('')
    }, 2000);
  }

  onUploadImage(productId: number) {
    if (!this.selectedFile) {
      this.message = 'No file selected.';
      return;
    }
  
    if (this.selectedFile.type !== 'image/jpg' && this.selectedFile.type !== 'image/jpeg') {
      this.message = 'Invalid file type. Only PNG and JPEG files are allowed.';
      return;
    }
  
    const file: File = new File([this.selectedFile], this.selectedFile.name, { type: this.selectedFile.type });
  
    this.productService.uploadImage(productId, file).subscribe(
      response => {
        console.log(response.message);
        
      },
      error => {
        console.log(error);
        this.message = 'An error occurred.';
      }
    );
  }
  
  

}
