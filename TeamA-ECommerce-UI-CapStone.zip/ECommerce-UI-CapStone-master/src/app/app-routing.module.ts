import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrderViewComponent } from './Components/Admin-Components/order-view/order-view.component';
import { ProductViewComponent } from './Components/Admin-Components/product-view/product-view.component';
import { ShipViewComponent } from './Components/Admin-Components/ship-view/ship-view.component';
import { UpdateUserComponent } from './Components/Admin-Components/update-user/update-user.component';
import { UserViewComponent } from './Components/Admin-Components/user-view/user-view.component';
import { LoginComponent } from './Components/Auth-Components/login/login.component';
import { PasswordComponent } from './Components/Auth-Components/password/password.component';
import { RegisterComponent } from './Components/Auth-Components/register/register.component';
import { TrackingComponent } from './Components/User-Components/tracking/tracking.component';
import { UserCartComponent } from './Components/User-Components/user-cart/user-cart.component';
import { UserHomeComponent } from './Components/User-Components/user-home/user-home.component';
import { UserPayComponent } from './Components/User-Components/user-pay/user-pay.component';
import { UserProductViewComponent } from './Components/User-Components/user-product-view/user-product-view.component';
import { UserOrderComponent } from './Components/User-Components/user-order/user-order.component';
import { ContactusComponent } from './Components/User-Components/contactus/contactus.component';
import { AboutComponent } from './Components/User-Components/about/about.component';
import { GuardGuard } from './Guard/guard.guard';
import { UnauthorizedComponent } from './Components/Auth-Components/unauthorized/unauthorized.component';

const routes: Routes = [

  // {path:"",component:LoginComponent, pathMatch: "full"},
  // {path: "home", component: UserHomeComponent,canActivate: [GuardGuard], data: { expectedRoles: [ 'Admin','User'] } },
  // {path:'about',component:AboutComponent},
  // { path: "login", component: LoginComponent},
  // { path: 'edit-user/:id', component: UpdateUserComponent },
  // { path: "register", component: RegisterComponent },
  // { path: 'password', component: PasswordComponent },
  // { path: 'products', component: ProductViewComponent },
  // { path: 'user-prod', component: UserProductViewComponent },
  // { path: 'user-cart', component: UserCartComponent },
  // { path: 'user-order', component: UserOrderComponent },
  // { path: 'user-pay/:id', component: UserPayComponent },
  // { path: 'track', component: TrackingComponent },
  // { path: 'carthome', component: UserCartComponent },
  // { path: 'prod-cart/:id', component: UserCartComponent },
  // { path: 'orders', component: OrderViewComponent },
  // { path: 'ship', component: ShipViewComponent },
  // { path: 'users', component: UserViewComponent },
  // { path: 'contact', component: ContactusComponent }

  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'home',
    component: UserHomeComponent,
    canActivate: [GuardGuard],
    data: { expectedRoles: ['Admin', 'User'] }

  },
  { path: 'about', component: AboutComponent },
  { path: 'edit-user/:id', component: UpdateUserComponent, },
  { path: 'password', component: PasswordComponent },
  { path: 'products', component: ProductViewComponent },
  {
    path: 'user-prod', component: UserProductViewComponent, canActivate: [GuardGuard],
    data: { expectedRoles: ['Admin', 'User'] }
  },
  {
    path: 'user-cart', component: UserCartComponent, canActivate: [GuardGuard],
    data: { expectedRoles: ['Admin', 'User'] }
  },
  {
    path: 'user-order', component: UserOrderComponent, canActivate: [GuardGuard],
    data: { expectedRoles: ['Admin', 'User'] }
  },
  {
    path: 'user-pay/:id', component: UserPayComponent, canActivate: [GuardGuard],
    data: { expectedRoles: ['Admin', 'User'] }
  },
  { path: 'track', component: TrackingComponent },
  { path: 'prod-cart/:id', redirectTo: 'user-cart/:id' },
  { path: 'orders', component: OrderViewComponent },
  {
    path: 'ship', component: ShipViewComponent, canActivate: [GuardGuard],
    data: { expectedRoles: ['Admin', 'User'] }
  },
  {
    path: 'users', component: UserViewComponent, canActivate: [GuardGuard],
    data: { expectedRoles: ['Admin', 'User'] }
  },
  {
    path: 'contact', component: ContactusComponent, canActivate: [GuardGuard],
    data: { expectedRoles: ['Admin', 'User'] }
  },
  {
    path: 'unauthorized', component: UnauthorizedComponent, canActivate: [GuardGuard],
    data: { expectedRoles: ['Visitor'] }
  },
  { path: '**', redirectTo: '/login', pathMatch: 'full' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
