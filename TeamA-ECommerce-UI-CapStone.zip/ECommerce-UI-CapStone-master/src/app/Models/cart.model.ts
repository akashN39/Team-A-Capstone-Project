import { CartItem } from "./cartItem.model";

export interface Cart {
  message: any;
  id: number;
  userId: number;
  items: CartItem[];
}