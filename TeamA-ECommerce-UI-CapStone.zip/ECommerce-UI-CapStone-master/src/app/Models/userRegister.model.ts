export interface UserRegister {
  userName: string;
  email: string;
  password: string;
  confirmPassword: string;
  city: string;
  address: string;
}
