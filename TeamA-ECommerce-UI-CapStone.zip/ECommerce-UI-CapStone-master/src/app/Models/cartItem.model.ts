export interface CartItem {
  id: number;
  productId: number;
  productName: string;
  productDescription:string;
  productImage:string;
  quantity: number;
  price: number;
}
