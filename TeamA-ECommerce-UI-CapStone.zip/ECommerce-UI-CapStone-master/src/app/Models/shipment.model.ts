export interface Shipment {
  id: string;
  orderId: number;
  customerName: string;
  customerEmail: string;
  customerPhoneNumber: string;
  shippingAddress: string;
  shippingCity: string;
  productsPurchased: string[];
  productQuantity: number[];
  paymentSuccessful: string;
  trackingNumber: string;
  deliveryStatus: string;
  orderCreatedAt: Date;
  orderStatus: string;
  shippingCreatedAt: Date;
}
