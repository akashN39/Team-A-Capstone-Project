import { OrderItem } from "./orderItem.model";

export interface Order {
  orderId: number;
  userId: number;
  userName: string;
  email: string;
  city: string;
  deliveryAddress: string;
  orderDate: string;
  totalAmount: number;
  orderStatus: string;
  orderItems: OrderItem[];
  shipmentDone: boolean;
}
