
export interface OrderItem {
  orderItemId: number;
  orderId: number;
  productId: number;
  productName: string;
  productDescription:string,
  quantity: number;
  price: number;
  order: any;
}
