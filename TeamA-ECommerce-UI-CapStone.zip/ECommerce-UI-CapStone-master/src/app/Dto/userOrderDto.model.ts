export interface OrderDto {
    orderId: number;
    userId: number;
    orderStatus: string;
    orderItems: OrderItemDto[];
  }
  
 export interface OrderItemDto {
    orderItemId: number;
    orderId: number;
    productName: string;
    quantity: number;
    price: number;
  }