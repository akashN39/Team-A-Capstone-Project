export interface UserFetch {
  Id: number;
  UserName: string;
  Email: string;
  City: string;
  Address: string;
  Role:string;
}
