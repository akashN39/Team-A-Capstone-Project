import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class NotifyService {

  constructor(private toastr: ToastrService) { }

  showSuccess(message: any, duration: number = 3000) {
    this.toastr.success(message, '', {
      timeOut: duration
    });
  }

  showError(message: any, duration: number = 3000) {
    this.toastr.error(message, '', {
      timeOut: duration
    });
  }

  showInfo(message: any, duration: number = 3000) {
    this.toastr.info(message, '', {
      timeOut: duration
    });
  }

  showWarning(message: any, duration: number = 3000) {
    this.toastr.warning(message, '', {
      timeOut: duration
    });
  }

}
