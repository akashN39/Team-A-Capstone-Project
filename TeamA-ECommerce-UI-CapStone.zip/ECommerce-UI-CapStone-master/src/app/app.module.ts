import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MatModule } from './StyleModules/mat/mat.module';
import { FormsModule } from '@angular/forms';
import { AdminHomeComponent } from './Components/Admin-Components/admin-home/admin-home.component';
import { UserHomeComponent } from './Components/User-Components/user-home/user-home.component';
import { NavbarComponent } from './Components/User-Components/navbar/navbar.component';
import { LoginComponent } from './Components/Auth-Components/login/login.component';
import { RegisterComponent } from './Components/Auth-Components/register/register.component';
import { PasswordComponent } from './Components/Auth-Components/password/password.component';
import { AuthServiceService } from './Services/auth-service.service';
import { GuardGuard } from './Guard/guard.guard';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './Interceptor/token.interceptor';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ProductViewComponent } from './Components/Admin-Components/product-view/product-view.component';
import { OrderViewComponent } from './Components/Admin-Components/order-view/order-view.component';
import { ShipViewComponent } from './Components/Admin-Components/ship-view/ship-view.component';
import { UpdateUserComponent } from './Components/Admin-Components/update-user/update-user.component';
import { UserViewComponent } from './Components/Admin-Components/user-view/user-view.component';
import { UserProductViewComponent } from './Components/User-Components/user-product-view/user-product-view.component';
import { UserCartComponent } from './Components/User-Components/user-cart/user-cart.component';
import { UserOrderComponent } from './Components/User-Components/user-order/user-order.component';
import { UserPayComponent } from './Components/User-Components/user-pay/user-pay.component';
import { TrackingComponent } from './Components/User-Components/tracking/tracking.component';
import { ContactusComponent } from './Components/User-Components/contactus/contactus.component';
import { AboutComponent } from './Components/User-Components/about/about.component';
import { UnauthorizedComponent } from './Components/Auth-Components/unauthorized/unauthorized.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';

@NgModule({
  declarations: [
    AppComponent,
    AdminHomeComponent,
    LoginComponent,
    UserHomeComponent,
    NavbarComponent,
    RegisterComponent,
    PasswordComponent,
    ProductViewComponent,
    OrderViewComponent,
    ShipViewComponent,
    UpdateUserComponent,
    UserViewComponent,
    UserProductViewComponent,
    UserCartComponent,
    UserOrderComponent,
    UserPayComponent,
    TrackingComponent,
    ContactusComponent,
    AboutComponent,
    UnauthorizedComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    ReactiveFormsModule,
    FormsModule,
    MatModule,
    HttpClientModule,
  ],
  providers: [AuthServiceService,
    GuardGuard, {
      provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true
    }],

  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
