export const environment = {
  production: false,
  unsplashAccessKey: 'c4XYQQBZtvuheIYePJRk8IB1F8MWjaJAH__AwQwKgWw'
};