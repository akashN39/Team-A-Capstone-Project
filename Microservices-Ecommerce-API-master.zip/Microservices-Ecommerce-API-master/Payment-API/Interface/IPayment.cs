﻿using Microsoft.AspNetCore.Mvc;
using Payment_API.DTO;
using Payment_API.Models;

namespace Payment_API.NewFolder
{
    public interface IPayment
    {
        Task<PaymentResponse> MakePayment(int OrderId,PaymentRequest paymentRequest);
        public  Task<List<Payment>> GetAllPayments();

        public Task<OrderDto> RetrieveOrderInformation(int orderId);
    }
}
