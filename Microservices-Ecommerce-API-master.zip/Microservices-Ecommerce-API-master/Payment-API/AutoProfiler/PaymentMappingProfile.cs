﻿using AutoMapper;
using Payment_API.DTO;
using Payment_API.Models;

namespace Payment_API.NewFolder
{
    public class PaymentMappingProfile : Profile
    {
        public PaymentMappingProfile()
        {
            CreateMap<PaymentRequest, Payment>();
        }
    }
}
