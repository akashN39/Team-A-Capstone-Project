﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Payment_API.DTO;
using Payment_API.Models;
using Payment_API.NewFolder;
using System.Data;

namespace Payment_API.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class PaymentController
    {

        private readonly IPayment _paymentService;

        public PaymentController(IPayment paymentService)
        {
            _paymentService = paymentService;
        }


        [HttpPost("{orderId}")]
        public async Task<ActionResult<PaymentResponse>> MakePayment(int orderId, [FromBody] PaymentRequest paymentRequest)
        {
            try
            {
                // Check if the order with the given ID exists
                var orderDto = await _paymentService.RetrieveOrderInformation(orderId);
                if (orderDto == null)
                {
                    throw new Exception($"NO ORDER ID PRESENT WITH ID : {orderId}");
                }

                var result = await _paymentService.MakePayment(orderId, paymentRequest);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception($"An error occurred while making Payment for Order with ID {orderId}: {ex.Message}");
            }
        }
        [HttpGet]
        public async Task<List<Payment>> GetAllPayments()
        {
            return await _paymentService.GetAllPayments();
        }


    }
}
