﻿using System.ComponentModel.DataAnnotations;

namespace Payment_API.DTO
{
    //public class OrderItemDto
    //{

    //    public string ProductName { get; set; } 

    //    public int Quantity { get; set; }

    //    public int Price { get; set; }
    //     public virtual Order Order { get; set; }
    //}
}
