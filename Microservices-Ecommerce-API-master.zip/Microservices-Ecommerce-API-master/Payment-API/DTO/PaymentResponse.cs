﻿namespace Payment_API.DTO
{
    public class PaymentResponse
    {


        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
       
        public string UserName { get; set; }
        public string Email { get; set; }
        public string City { get; set; }
        public int OrderId { get; set; }
        public string DeliveryAddress { get; set; } = string.Empty;
        public string OrderStatus { get; set; } = string.Empty;

        public string ProductsPurchased { get; set; } = string.Empty;
        public string ProductQuantity { get; set; } = string.Empty;

        public int AmountPaid { get; set; }

        public DateTime PaymentDate { get; set; }

    }
}
