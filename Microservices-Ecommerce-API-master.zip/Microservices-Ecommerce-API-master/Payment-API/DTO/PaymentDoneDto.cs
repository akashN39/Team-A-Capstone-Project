﻿namespace Payment_API.DTO
{
    public class PaymentDoneDto
    {
        public string Message { get; set; }
        public bool IsSuccessful { get; set; }
    }
}
