﻿using System.ComponentModel.DataAnnotations;

namespace Payment_API.DTO
{
    public class OrderDto
    {
        public int OrderId { get; set; }

        public string UserName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string City { get; set; } = string.Empty;

        public string DeliveryAddress { get; set; } = string.Empty;
        public string OrderStatus { get; set; }=string.Empty;

        public int TotalAmount { get; set; }
        public virtual ICollection<OrderItemDto> OrderItems { get; set; }

    }

    public class OrderItemDto
    {

        public string ProductName { get; set; }

        public int Quantity { get; set; }

        public int Price { get; set; }

        public virtual OrderDto Order { get; set; }
    }
}
