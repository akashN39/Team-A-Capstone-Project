﻿using AutoMapper;
using Payment_API.ContextFile;
using Payment_API.DTO;
using Payment_API.Models;
using System.Text.Json;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Payment_API.NewFolder;

namespace Payment_API.Service
{
    public class PaymentService : IPayment
    {
        private readonly PaymentDbContext _context;
        private readonly IMapper _mapper;

        public PaymentService(PaymentDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

       
        public async Task<PaymentResponse> MakePayment(int OrderId,PaymentRequest paymentRequest)
        {
            try
            {
                //Check if payment has already been made for this order

               var existingPayment = await _context.Payments.FirstOrDefaultAsync(p => p.OrderId == OrderId);
                if (_context.Payments.Any(p => p.OrderId == OrderId))
                    {
                        return new PaymentResponse
                        {
                            IsSuccessful = false,
                            Message = "Payment has already been made for this order"
                        };
                    }


                // Retrieve order information from the Order microservice
                var orderDto = await RetrieveOrderInformation(OrderId);

                // Map PaymentRequest to Payment model using AutoMapper
                var totalAmount = orderDto.TotalAmount;
                var payment = _mapper.Map<Payment>(paymentRequest);
                payment.PaymentDate = DateTime.UtcNow;
                payment.Amount = totalAmount;
                payment.CardHolderName = orderDto.UserName;
                payment.OrderId = orderDto.OrderId;

                // Save payment information to the database
                _context.Payments.Add(payment);
                await _context.SaveChangesAsync();

                // Update order status in the Order microservice
                var orderStatusResponse = await UpdateOrderStatus(orderDto.OrderId, "OrderSuccessful");

                if (orderStatusResponse.IsSuccessStatusCode)
                {
                    payment.IsSuccessful = true;
                    await _context.SaveChangesAsync();
                }
                if (!orderStatusResponse.IsSuccessStatusCode)
                {
                    return new PaymentResponse
                    {
                        IsSuccessful = false,
                        Message = $"Failed to update order status to OrderSuccessful for order {orderDto.OrderId}"
                    };
                }

                // Get the list of product names and quantities from the OrderItems collection
                var productNames = orderDto.OrderItems.Select(oi => oi.ProductName).ToList();
                var productQuantities = orderDto.OrderItems.Select(oi => oi.Quantity).ToList();

                // Return PaymentResponse with success message and order information
                return new PaymentResponse
                {
                    IsSuccessful = true,
                    Message = "Payment successful",
                    ProductsPurchased = string.Join(", ", productNames),
                    ProductQuantity = string.Join(", ", productQuantities),
                    UserName = orderDto.UserName,
                    Email = orderDto.Email,
                    City = orderDto.City,
                    DeliveryAddress= orderDto.DeliveryAddress,
                    OrderId= orderDto.OrderId,
                    OrderStatus= "Successfull!",
                    AmountPaid = totalAmount,
                    PaymentDate = DateTime.UtcNow
                };
            }
            catch (Exception ex)
            {
                throw new Exception("");
            }
        }


        public async Task<OrderDto> RetrieveOrderInformation(int orderId)
        {
            try
            {
                var orderUrl = $"https://localhost:7186/api/Order/{orderId}";
                var httpClient = new HttpClient();
                var response = await httpClient.GetAsync(orderUrl);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                var orderDto = await response.Content.ReadFromJsonAsync<OrderDto>();
                return orderDto;
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"An error occurred while retrieving Order with ID '{orderId}': {ex.Message}", ex);
            }
        }

        private async Task<HttpResponseMessage> UpdateOrderStatus(int orderId, string orderStatus)
        {
            try
            {
                var orderStatusUrl = $"https://localhost:7186/api/Order/{orderId}";
                var orderStatusUpdateDto = new OrderStatusUpdateDto { OrderStatus = orderStatus };
                var orderStatusContent = new StringContent(JsonSerializer.Serialize(orderStatusUpdateDto), Encoding.UTF8, "application/json");
                var httpClient = new HttpClient();
                var response = await httpClient.PatchAsync(orderStatusUrl, orderStatusContent);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception("");
            }
        }
        public async Task<List<Payment>> GetAllPayments()
        {
            return await _context.Payments.ToListAsync();
        }


      



    }
}
