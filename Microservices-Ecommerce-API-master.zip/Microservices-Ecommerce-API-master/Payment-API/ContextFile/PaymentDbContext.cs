﻿using Microsoft.EntityFrameworkCore;
using Payment_API.Models;

namespace Payment_API.ContextFile
{
    public class PaymentDbContext : DbContext
    {
        public PaymentDbContext(DbContextOptions<PaymentDbContext> options)
            : base(options)
        {
        }

        public DbSet<Payment> Payments { get; set; }
    }
}
