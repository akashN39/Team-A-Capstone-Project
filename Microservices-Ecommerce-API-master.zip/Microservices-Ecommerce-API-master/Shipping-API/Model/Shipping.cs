﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Shipping_API.Model
{
    [BsonIgnoreExtraElements]
    public class Shipping
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public int OrderId { get; set; }

        public string CustomerName { get; set; }

        public string CustomerEmail { get; set; }
        public string CustomerPhoneNumber { get; set; } = string.Empty;
        public string ShippingAddress { get; set; }

        public string ShippingCity { get; set; }

        public string ProductsPurchased { get; set; } = string.Empty;
        public string ProductQuantity { get; set; } = string.Empty;
        public string PaymentSuccessful { get; set; } = string.Empty;

        public string TrackingNumber { get; set; }= string.Empty;

        public string DeliveryStatus { get; set; } = "On Process!";

        public DateTime OrderCreatedAt { get; set; }

        public string OrderStatus { get; set; } = string.Empty;
        public DateTime ShippingCreatedAt { get; set; }
    }
}
