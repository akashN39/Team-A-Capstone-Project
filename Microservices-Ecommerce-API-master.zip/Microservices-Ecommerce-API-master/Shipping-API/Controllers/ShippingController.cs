﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson.IO;
using MongoDB.Driver;
using Shipping_API.CustomExceptionHandle;
using Shipping_API.Dto;
using Shipping_API.Interface;
using Shipping_API.Model;

namespace Shipping_API.Controllers
{
    [EnableCors("angular")]
    [ApiController]
    [Route("api/[Controller]")]
    public class ShippingController : ControllerBase
    {
        private readonly IShipping _shippingService;

        public ShippingController(IShipping shipping)
        {
            _shippingService = shipping;
        }
        
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var shippings = await _shippingService.GetAllAsync();
            return Ok(shippings);
        }
        [HttpPost("create-shipping/{orderId}")]
        public async Task<ActionResult<Shipping>> CreateShipping(int orderId)
        {
            try
            {
                // Check if the order with the given ID exists
                var orderDto = await _shippingService.GetOrderDto(orderId);
                if (orderDto == null)
                {
                    return NotFound(new { Message = $"Order with ID {orderId} not found." });
                }

                // Create the shipping object from the order information
                var shipping = await _shippingService.CreateShippingFromOrder(orderId);

                return Ok(shipping);    
            }
            catch (CustomExceptionHandler ex)
            {
                // handle the exception by throwing a custom exception
                throw new CustomExceptionHandler($"An error occurred while creating shipping for order with ID {orderId} !");
            }
        }

    }


}
