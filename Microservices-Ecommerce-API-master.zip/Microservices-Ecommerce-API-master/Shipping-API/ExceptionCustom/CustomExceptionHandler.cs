﻿namespace Shipping_API.CustomExceptionHandle
{
    public class CustomExceptionHandler : Exception
    {
        public CustomExceptionHandler(string message) : base(message)
        {
        }
    }
}
