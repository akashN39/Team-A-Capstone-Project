﻿using AutoMapper;
using Shipping_API.Dto;
using Shipping_API.Model;

namespace Shipping_API.ProfilerMap
{
    public class AutoMapperProfiler : Profile
    {
        public AutoMapperProfiler()
        {
            CreateMap<OrderDto, Shipping>();
        }
    }
}
