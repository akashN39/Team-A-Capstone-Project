﻿using Shipping_API.Dto;
using Shipping_API.Model;

namespace Shipping_API.Interface
{
    public interface IShipping
    {
        Task<Shipping> CreateShippingFromOrder(int orderId);
        Task<List<Shipping>> GetAllAsync();
        Task<OrderDto> GetOrderDto(int orderId);
    }
}
