﻿namespace Shipping_API.Dto
{
    public class OrderDto
    {

        public int OrderId { get; set; }

        public string UserName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string City { get; set; } = string.Empty;

        public string DeliveryAddress { get; set; } = string.Empty;
        public string OrderStatus { get; set; } = string.Empty;
        public DateTime OrderDate { get; set; }
        public int TotalAmount { get; set; }
        public string ProductsPurchased { get; set; } = string.Empty;
        public string ProductQuantity { get; set; } = string.Empty;

    }

}
