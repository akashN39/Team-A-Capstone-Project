﻿using MongoDB.Driver;
using Shipping_API.Dto;
using Shipping_API.Model;
using AutoMapper;
using Shipping_API.Interface;

namespace Shipping_API.Repsoitory
{
    public class ShippingService : IShipping
    {
        private readonly IMongoCollection<Shipping> _shippingCollection;
        private readonly IMapper _mapper;

        public ShippingService(IMongoDatabase mongoDatabase, IMapper mapper)
        {
            _shippingCollection = mongoDatabase.GetCollection<Shipping>("shipping");
            _mapper = mapper;
        }
        public async Task<List<Shipping>> GetAllAsync()
        {
            return await _shippingCollection.Find(_ => true).ToListAsync();
        }

        public async Task<Shipping> CreateShippingFromOrder(int orderId)
        {
            try
            {


                // Retrieve order information from the Order microservice
                var orderDto = await GetOrderDto(orderId);

                // Map order information to Shipping model using AutoMapper
                var shipping = _mapper.Map<Shipping>(orderDto);
                shipping.OrderId = orderDto.OrderId;
                shipping.OrderCreatedAt = orderDto.OrderDate;
                shipping.OrderStatus = orderDto.OrderStatus;
                shipping.ProductsPurchased = orderDto.ProductsPurchased;
                shipping.ProductQuantity = orderDto.ProductQuantity;
                shipping.CustomerPhoneNumber = GetMobileNumber();
                shipping.PaymentSuccessful = "Successfull!";
                shipping.CustomerEmail = orderDto.UserName;
                shipping.CustomerName = orderDto.UserName;
                shipping.TrackingNumber = GetTrackingNumber();
                shipping.DeliveryStatus = "On Process!";
                shipping.ShippingAddress = orderDto.DeliveryAddress;
                shipping.ShippingCity = orderDto.City;
                shipping.ShippingCreatedAt = DateTime.UtcNow;

                // Save shipping information to the database
                await _shippingCollection.InsertOneAsync(shipping);

                return shipping;
            }
            catch (Exception ex)
            {
                throw new Exception($"An error occurred while creating shipping for order with ID {orderId}: {ex.Message}");
            }
        }

        public async Task<OrderDto> GetOrderDto(int orderId)
        {
            try
            {
                string orderUrl = $"https://localhost:7186/api/Order/{orderId}";
                using var httpClient = new HttpClient();
                using var response = await httpClient.GetAsync(orderUrl);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                var orderDto = await response.Content.ReadFromJsonAsync<OrderDto>();
                return orderDto;
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"An error occurred while retrieving Order with ID '{orderId}': {ex.Message}", ex);
            }
        }


        private string GetTrackingNumber()
        {
            var random = new Random();
            var trackingNumber = random.Next(10000, 99999).ToString();
            return trackingNumber;
        }
        private string GetMobileNumber()
        {
            var random = new Random();
            var trackingNumber = random.Next(70000000, 80009999).ToString();
            return trackingNumber;
        }
    }



}
