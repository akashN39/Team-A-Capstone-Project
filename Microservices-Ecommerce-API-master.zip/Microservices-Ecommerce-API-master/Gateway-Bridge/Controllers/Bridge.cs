﻿using Gateway_Bridge.DTO;
using Microsoft.AspNetCore.Mvc;

namespace Gateway_Bridge.Controllers
{
    [ApiController]
    [Route("api/Bridge")]
    public class Bridge:ControllerBase
    {
        [HttpGet]
        [Route("allUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            var url = "https://localhost:7094/api/User";
            using var client = new HttpClient();
            var content = await client.GetFromJsonAsync<IEnumerable<UserFetchDto>>(url);
            Console.WriteLine(content);
            return Ok(content);
        }
    }
}
