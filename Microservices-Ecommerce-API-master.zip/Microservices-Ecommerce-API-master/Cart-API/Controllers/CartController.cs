﻿using Cart_API.Command;
using Cart_API.DTO;
using Cart_API.Interface;
using Cart_API.Models;
using Cart_API.Query;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace Cart_API.Controllers
{
    [ApiController]
    [EnableCors("angular")]
    [Route("api/[controller]")]
    public class CartController : ControllerBase
    {

        private readonly IMediator _mediator;

        public CartController(IMediator mediator)
        {
            _mediator = mediator;
        }
       
        [HttpPost("{userId}")]
        public async Task<ActionResult<Cart>> AddToCart(int userId, AddCartItemRequest request)
        {
            var command = new AddToCartCommand { UserId = userId, Request = request };
            var cart = await _mediator.Send(command);

            if (cart == null)
            {
                return NotFound();
            }

            return Ok(new { message = "Item added to cart successfully." });
        }
        [HttpGet("{userId}")]
        public async Task<ActionResult<Cart>> GetCart(int userId)
        {
            var query = new GetCartQuery(userId);
            var cart = await _mediator.Send(query);

            if (cart == null)
            {
                return NotFound(new {Message=$"No Cart Found with UserId: {userId}"});
            }

            return Ok(cart);
        }

        [HttpPut("{userId}/{productId}")]
        public async Task<IActionResult> UpdateCartItem(int userId, int productId, UpdateCartItemRequest request)
        {
            var command = new UpdateCartItemCommand
            {
                UserId = userId,
                ProductId = productId,
                Request = request
            };

            var result = await _mediator.Send(command);

            if (!result)
            {
                return NotFound();
            }

            return Ok(new { message = "Cart item updated successfully." });
        }
        
        //REMOVES PRODUCT-ITEM FROM CART ITEM OF USER
        [HttpDelete("{userId}/{productId}")]
        public async Task<IActionResult> RemoveCartItem(int userId, int productId)
        {
            var result = await _mediator.Send(new RemoveCartItemCommand { UserId = userId, ProductId = productId });
            if (!result)
            {
                return NotFound(new { Message = $"No Cart Found with UserId: {userId} OR ProductId: {productId}" });
            }
            return Ok(new { message = "Cart item removed successfully." });
        }

        
        //CLEAR-ENTIRE-CART
        [HttpDelete("{userId}")]
        public async Task<IActionResult> ClearCart(int userId)
        {
            var result = await _mediator.Send(new ClearCartCommand { UserId = userId });
            if (!result)
            {
                return NotFound(new {Message = $"No Cart Found with UserId: {userId}"});
            }
            return Ok(new { message = "Cart cleared successfully." });
        }
        
        //UPDATES-CART WHEN ORDER DONE IT UPDATES ENTIRE CART OF USER AND EMPTY
        //COMES FROM ORDER SERVICE
        [HttpPut("{userId}")]
        public async Task<IActionResult> UpdateCart(int userId, [FromBody] Cart cart)
        {
            var command = new UpdateCartCommand { UserId = userId, Cart = cart };
            var result = await _mediator.Send(command);

            if (result)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }

    }

}
