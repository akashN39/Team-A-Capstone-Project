﻿using Cart_API.Models;
using MediatR;

namespace Cart_API.Query
{
    public class GetCartQuery : IRequest<Cart>
    {
        public int UserId { get; set; }
        public GetCartQuery(int userId)
        {
            UserId = userId;
        }
    }
}
