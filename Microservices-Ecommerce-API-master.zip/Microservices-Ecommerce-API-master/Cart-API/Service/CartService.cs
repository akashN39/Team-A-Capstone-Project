﻿using Cart_API.ContextFile;
using Cart_API.DTO;
using Cart_API.Interface;
using Cart_API.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Net;

namespace Cart_API.Service
{
    public class CartService : ICart
    {
        private readonly HttpClient _httpClient;
        private readonly CartContext _context;

        public CartService(HttpClient httpClient, CartContext context)
        {
            _httpClient = httpClient;
            _context = context;
        }
        public async Task<Cart> GetCartAsync(int userId)
        {
            var cart = await _context.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null)
            {
                cart = new Cart { UserId = userId, Items = new List<CartItem>() };
                _context.Carts.Add(cart);
                await _context.SaveChangesAsync();
            }

            return cart;
        }

        public async Task<bool> RemoveFromCartAsync(int userId, int productId)
        {
            var cart = await _context.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null)
            {
                return false;
            }

            var cartItem = cart.Items.FirstOrDefault(i => i.ProductId == productId);

            if (cartItem == null)
            {
                return false;
            }

            cart.Items.Remove(cartItem);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateCartItemAsync(int userId, int productId, UpdateCartItemRequest request)
        {
            var cart = await _context.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null)
            {
                return false;
            }

            var cartItem = cart.Items.FirstOrDefault(i => i.ProductId == productId);

            if (cartItem == null)
            {
                return false;
            }
            cartItem.Quantity = request.Quantity;
            await _context.SaveChangesAsync();

            return true;
        }
        public async Task<bool> ClearCartAsync(int userId)
        {
            var cart = await _context.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null)
            {
                return false;
            }

            _context.Carts.Remove(cart);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UpdateCartAsync(int userId, Cart cart)
        {
            var existingCart = await _context.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == userId);
            if (existingCart == null)
            {
                return false;
            }

            existingCart.Items.Clear();
            existingCart.Items = existingCart.Items.Concat(cart.Items).ToList();

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateException)
            {
                // handle exception
                return false;
            }
        }

        public async Task<Cart> AddToCartAsync(int userId, AddCartItemRequest request)
        {
            var user = await GetUserByIdAsync(userId);
            var product = await GetProductByIdAsync(request.ProductId);


            // Add item to cart
            var cart = await _context.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null)
            {
                cart = new Cart { UserId = userId, Items = new List<CartItem>() };
                _context.Carts.Add(cart);
            }

            var cartItem = cart.Items.FirstOrDefault(i => i.ProductId == request.ProductId);

            if (cartItem == null)
            {
                cartItem = new CartItem
                {
                    ProductId = request.ProductId,
                    ProductName=product.ProductName,
                    ProductImage=product.ProductImage,
                    ProductDescription=product.ProductDescription,
                    Quantity = request.Quantity,
                    Price = product.ProductPrice
                };
                cart.Items.Add(cartItem);
            }
            else
            {
                cartItem.Quantity += request.Quantity;
            }

            await _context.SaveChangesAsync();
            return cart;
        }
        public async Task<UserFetchDto> GetUserByIdAsync(int userId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"https://localhost:7094/api/User/{userId}");
                response.EnsureSuccessStatusCode();
                var content = await response.Content.ReadAsStringAsync();
                var user = JsonConvert.DeserializeObject<UserFetchDto>(content);

                return user;
            }
            catch (HttpRequestException ex)
            {
                throw new ApplicationException($"An error occurred while retrieving user with ID '{userId}': {ex.Message}", ex);
            }
        }

        public async Task<ProductDto> GetProductByIdAsync(int productId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"https://localhost:7086/api/Product/{productId}");
                response.EnsureSuccessStatusCode();
                var content = await response.Content.ReadAsStringAsync();
                var product = JsonConvert.DeserializeObject<ProductDto>(content);

                return product;
            }
            catch (HttpRequestException ex)
            {
                throw new ApplicationException($"An error occurred while retrieving product with ID '{productId}': {ex.Message}", ex);
            }
        }

    }





}


