﻿using MediatR;

namespace Cart_API.Command
{
    public class ClearCartCommand : IRequest<bool>
    {
        public int UserId { get; set; }
    }
}
