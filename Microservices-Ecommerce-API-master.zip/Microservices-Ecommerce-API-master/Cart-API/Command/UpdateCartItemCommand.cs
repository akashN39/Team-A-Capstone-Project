﻿using Cart_API.DTO;
using Cart_API.Models;
using MediatR;

namespace Cart_API.Command
{
    public class UpdateCartItemCommand : IRequest<bool>
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public UpdateCartItemRequest Request { get; set; }
    }
}
