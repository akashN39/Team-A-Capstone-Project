﻿using Cart_API.DTO;
using MediatR;

namespace Cart_API.Command
{
    public class AddToCartCommand : IRequest<bool>
    {
        public int UserId { get; set; }
        public AddCartItemRequest Request { get; set; }
    }
}
