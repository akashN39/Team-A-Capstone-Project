﻿using MediatR;

namespace Cart_API.Command
{
    public class RemoveCartItemCommand : IRequest<bool>
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
    }
}
