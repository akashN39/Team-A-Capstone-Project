﻿using Cart_API.Models;
using MediatR;

namespace Cart_API.Command
{
    public class UpdateCartCommand : IRequest<bool>
    {
        public int UserId { get; set; }
        public Cart Cart { get; set; }
    }
}
