﻿using Cart_API.DTO;
using Cart_API.Models;
using System.Net;

namespace Cart_API.Interface
{
    public interface ICart
    {
        Task<Cart> GetCartAsync(int userId);
        public  Task<bool> ClearCartAsync(int userId);
        Task<bool> RemoveFromCartAsync(int userId, int productId);
        Task<bool> UpdateCartItemAsync(int userId, int productId, UpdateCartItemRequest request);

        public Task<bool> UpdateCartAsync(int userId, Cart cart);
        public Task<Cart> AddToCartAsync(int userId, AddCartItemRequest request);

        public  Task<UserFetchDto> GetUserByIdAsync(int userId);
        public  Task<ProductDto> GetProductByIdAsync(int productId);
    }
}
