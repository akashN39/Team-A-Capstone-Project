﻿using System.ComponentModel.DataAnnotations;

namespace Cart_API.Models
{
    public class Cart
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int UserId { get; set; }

        public ICollection<CartItem> Items { get; set; }
    }
}
