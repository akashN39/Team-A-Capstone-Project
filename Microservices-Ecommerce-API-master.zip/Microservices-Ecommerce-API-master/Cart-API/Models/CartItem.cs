﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Cart_API.Models
{
    public class CartItem
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int ProductId { get; set; }
        [Required]
        public string ProductName { get; set; }

        public string? ProductImage { get; set; }

        public string? ProductDescription { get; set; }

        [Required]
        public int Quantity { get; set; } = 1;

        public int Price { get; set; }

        [Required]
        public int CartId { get; set; }

        [ForeignKey("CartId")]
        public Cart Cart { get; set; }
    }
}
