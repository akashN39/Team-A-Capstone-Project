﻿namespace Cart_API.DTO
{
    public class AddCartItemRequest
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; } = 1; // default value is 1
    }
}
