﻿using Newtonsoft.Json;
using Product_Category_API.Models;
using System.ComponentModel.DataAnnotations;

namespace Cart_API.DTO
{
    public class ProductDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public int ProductPrice { get; set; }
        public string ProductQuantity { get; set; }
        public string ProductImage { get; set; }
        public int CategoryId { get; set; }
        public CategoryDto Category { get; set; }
    }

    public class CategoryDto
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }

}
