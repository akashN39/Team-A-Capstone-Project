﻿namespace Cart_API.DTO
{
        public class UpdateCartItemRequest
        {
            public int Quantity { get; set; }
        }
}
