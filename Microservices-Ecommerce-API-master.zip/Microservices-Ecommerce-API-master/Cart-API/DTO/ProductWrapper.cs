﻿namespace Cart_API.DTO
{
    public class ProductWrapper
    {
        public ProductDto Product { get; set; }
    }
}
