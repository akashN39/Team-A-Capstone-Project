﻿using Cart_API.Command;
using Cart_API.Interface;
using MediatR;

namespace Cart_API.Handler
{
    public class ClearCartCommandHandler : IRequestHandler<ClearCartCommand, bool>
    {
        private readonly ICart _cartService;

        public ClearCartCommandHandler(ICart cartService)
        {
            _cartService = cartService;
        }

        public async Task<bool> Handle(ClearCartCommand request, CancellationToken cancellationToken)
        {
            return await _cartService.ClearCartAsync(request.UserId);
        }
    }
}
