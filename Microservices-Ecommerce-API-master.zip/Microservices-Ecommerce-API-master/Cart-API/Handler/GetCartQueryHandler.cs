﻿using Cart_API.Interface;
using Cart_API.Models;
using Cart_API.Query;
using MediatR;

namespace Cart_API.Handler
{
    public class GetCartQueryHandler : IRequestHandler<GetCartQuery, Cart>
    {
        private readonly ICart _cartService;

        public GetCartQueryHandler(ICart cartService)
        {
            _cartService = cartService;
        }

        public async Task<Cart> Handle(GetCartQuery request, CancellationToken cancellationToken)
        {
            var cart = await _cartService.GetCartAsync(request.UserId);
            return cart;
        }
    }
}
