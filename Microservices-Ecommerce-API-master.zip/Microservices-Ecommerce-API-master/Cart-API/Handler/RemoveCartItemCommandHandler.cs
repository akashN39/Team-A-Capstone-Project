﻿using Cart_API.Command;
using Cart_API.Interface;
using MediatR;

namespace Cart_API.Handler
{
    public class RemoveCartItemCommandHandler : IRequestHandler<RemoveCartItemCommand, bool>
    {
        private readonly ICart _repository;

        public RemoveCartItemCommandHandler(ICart repository)
        {
            _repository = repository;
        }

        public async Task<bool> Handle(RemoveCartItemCommand command, CancellationToken cancellationToken)
        {
            var result = await _repository.RemoveFromCartAsync(command.UserId, command.ProductId);
            return result;
        }
    }
}
