﻿using Cart_API.Command;
using Cart_API.Interface;
using Cart_API.Models;
using MediatR;

namespace Cart_API.Handler
{
    public class UpdateCartItemCommandHandler : IRequestHandler<UpdateCartItemCommand, bool>
    {
        private readonly ICart _cartService;

        public UpdateCartItemCommandHandler(ICart cartService)
        {
            _cartService = cartService;
        }

        public async Task<bool> Handle(UpdateCartItemCommand command, CancellationToken cancellationToken)
        {
            return await _cartService.UpdateCartItemAsync(command.UserId, command.ProductId, command.Request);
        }
    }
}
