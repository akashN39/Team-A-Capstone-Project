﻿using Cart_API.Command;
using Cart_API.Interface;
using Cart_API.Service;
using MediatR;

namespace Cart_API.Handler
{
    public class UpdateCartHandler : IRequestHandler<UpdateCartCommand, bool>
    {
        private readonly ICart _cartService;

        public UpdateCartHandler(ICart cartService)
        {
            _cartService = cartService;
        }

        public async Task<bool> Handle(UpdateCartCommand request, CancellationToken cancellationToken)
        {
            return await _cartService.UpdateCartAsync(request.UserId, request.Cart);
        }
    }
}
