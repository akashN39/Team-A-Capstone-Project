﻿using Cart_API.Command;
using Cart_API.Interface;
using MediatR;

namespace Cart_API.Handler
{
    public class AddToCartCommandHandler : IRequestHandler<AddToCartCommand, bool>
    {
        private readonly ICart _cartService;

        public AddToCartCommandHandler(ICart cartService)
        {
            _cartService = cartService;
        }

        public async Task<bool> Handle(AddToCartCommand request, CancellationToken cancellationToken)
        {
            var cart = await _cartService.AddToCartAsync(request.UserId, request.Request);
            return cart != null;
        }
    }
}
