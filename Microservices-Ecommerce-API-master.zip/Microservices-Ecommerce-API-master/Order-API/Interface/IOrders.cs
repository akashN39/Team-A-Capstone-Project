﻿using Microsoft.AspNetCore.Mvc;
using Order_API.DTO;
using Order_API.Models;
using System.Net.Http;

namespace Order_API.Interface
{
    public interface IOrders
    {
        public Task<PlaceOrderResponseDto> PlaceOrder(PlaceOrderRequestDto request);
        public Task<IEnumerable<Order>> GetOrders();
        Task<bool> RemoveOrderAsync(int orderId);

        public Task UpdateCart(Cart cart);

        public Task<Cart> GetCart(int userId);
        public Task<UserDto> GetUser(int userId);

        public  Task<Order> GetOrderById(int orderId);

        Task UpdateOrderStatusAsync(int orderId, string orderStatus);


        //FOR-UPDATE-ORDER-STATUS METHOD!
        Task<Order> GetOrderByIdAsync(int id);

        Task UpdateOrderStatusAsync(Order order, OrderStatusUpdateDto orderStatusUpdateDto);
        //GET-ORDERS-BY-USERID
        public  Task<List<Order>> GetOrdersByUserId(int userId);
    }
}
