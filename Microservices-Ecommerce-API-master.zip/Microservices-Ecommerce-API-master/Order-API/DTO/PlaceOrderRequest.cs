﻿namespace Order_API.DTO
{
    public class PlaceOrderRequestDto
    {
        public int UserId { get; set; }
      
    }
}
