﻿using Cart_API.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Order_API.DTO
{
    public class CartItem
    {

        public int ProductId { get; set; }

        public string ProductName { get; set; } = string.Empty;
        public string? ProductImage { get; set; }

        public string? ProductDescription { get; set; }

        public int Quantity { get; set; }

        public int Price { get; set; }

        public int CartId { get; set; }

        public Cart Cart { get; set; }
    }
}
