﻿using Cart_API.Models;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Order_API.DTO
{
    public class Cart
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public ICollection<CartItem> Items { get; set; }
    }
}
