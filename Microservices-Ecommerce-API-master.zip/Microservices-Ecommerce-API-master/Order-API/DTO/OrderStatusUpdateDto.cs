﻿namespace Order_API.DTO
{
    public class OrderStatusUpdateDto
    {
        public string OrderStatus { get; set; }
    }
}
