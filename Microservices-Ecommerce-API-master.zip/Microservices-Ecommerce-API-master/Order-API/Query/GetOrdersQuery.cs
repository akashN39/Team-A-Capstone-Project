﻿using MediatR;
using Order_API.Models;

namespace Order_API.Query
{
    public class GetOrdersQuery : IRequest<IEnumerable<Order>>
    {
    }
}
