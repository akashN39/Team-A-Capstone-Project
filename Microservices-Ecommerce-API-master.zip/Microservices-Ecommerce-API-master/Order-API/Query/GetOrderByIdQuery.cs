﻿using MediatR;
using Order_API.Models;

namespace Order_API.Query
{
    public class GetOrderByIdQuery : IRequest<Order>
    {
        public int OrderId { get; set; }
    }
}
