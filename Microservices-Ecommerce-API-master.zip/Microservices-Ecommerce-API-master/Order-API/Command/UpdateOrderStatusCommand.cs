﻿using MediatR;
using Order_API.DTO;

namespace Order_API.Command
{
    // Command
    public class UpdateOrderStatusCommand : IRequest
    {
        public int Id { get; set; }
        public OrderStatusUpdateDto OrderStatusUpdateDto { get; set; }
    }
}
