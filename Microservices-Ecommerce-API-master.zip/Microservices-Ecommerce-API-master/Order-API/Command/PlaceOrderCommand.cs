﻿using MediatR;
using Order_API.DTO;

namespace Order_API.Command
{
    public class PlaceOrderCommand : IRequest<int>
    {
        public int UserId { get; set; }
    }
}
