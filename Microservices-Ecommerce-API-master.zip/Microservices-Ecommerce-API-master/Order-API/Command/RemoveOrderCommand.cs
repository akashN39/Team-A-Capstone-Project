﻿using MediatR;

namespace Order_API.Command
{
    public class RemoveOrderCommand : IRequest<bool>
    {
        public int OrderId { get; set; }
    }
}
