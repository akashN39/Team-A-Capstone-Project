﻿using AutoMapper;
using MediatR;
using Order_API.ContextFile;
using Order_API.ExceptionHandling;
using Order_API.Interface;
using Order_API.Models;
using Order_API.Service;

namespace Order_API.Handlers
{

    public class GetOrdersByUserIdQuery : IRequest<IEnumerable<Order>>
    {
        public int UserId { get; set; }
    }


    public class GetOrdersByUserIdQueryHandler : IRequestHandler<GetOrdersByUserIdQuery, IEnumerable<Order>>
    {
        private readonly IOrders _service;

        public GetOrdersByUserIdQueryHandler(IOrders service)
        {
            _service = service;
        }

        public async Task<IEnumerable<Order>> Handle(GetOrdersByUserIdQuery request, CancellationToken cancellationToken)
        {
            var orders = await _service.GetOrdersByUserId(request.UserId);

            if (orders == null || !orders.Any())
            {
                throw new NotFoundException($"No orders found for user ID: {request.UserId}");
            }

            return orders;
        }
    }
}

