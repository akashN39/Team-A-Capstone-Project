﻿using MediatR;
using Order_API.Interface;
using Order_API.Models;
using Order_API.Query;
using Order_API.Service;

namespace Order_API.Handlers
{
    // Define the handler
    public class GetOrdersQueryHandler : IRequestHandler<GetOrdersQuery, IEnumerable<Order>>
    {
        private readonly IOrders _service;

        public GetOrdersQueryHandler(IOrders service)
        {
            _service = service;
        }

        public async Task<IEnumerable<Order>> Handle(GetOrdersQuery request, CancellationToken cancellationToken)
        {
            return await _service.GetOrders();
        }
    }
}
