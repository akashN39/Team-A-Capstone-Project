﻿using MediatR;
using Order_API.Command;
using Order_API.DTO;
using Order_API.Interface;
using Order_API.Service;

namespace Order_API.Handlers
{
    public class PlaceOrderCommandHandler : IRequestHandler<PlaceOrderCommand, int>
    {
        private readonly IOrders _orderService;

        public PlaceOrderCommandHandler(IOrders orderService)
        {
            _orderService = orderService;
        }

        public async Task<int> Handle(PlaceOrderCommand request, CancellationToken cancellationToken)
        {
            var response = await _orderService.PlaceOrder(new PlaceOrderRequestDto { UserId = request.UserId });
            return response.OrderId;
        }
    }
}
