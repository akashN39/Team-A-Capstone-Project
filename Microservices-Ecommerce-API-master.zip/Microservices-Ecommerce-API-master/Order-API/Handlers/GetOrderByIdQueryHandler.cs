﻿using MediatR;
using Order_API.Interface;
using Order_API.Models;
using Order_API.Query;
using Order_API.Service;

namespace Order_API.Handlers
{
    public class GetOrderByIdQueryHandler : IRequestHandler<GetOrderByIdQuery, Order>
    {
        private readonly IOrders _orderService;

        public GetOrderByIdQueryHandler(IOrders orderService)
        {
            _orderService = orderService;
        }

        public async Task<Order> Handle(GetOrderByIdQuery request, CancellationToken cancellationToken)
        {
            var order = await _orderService.GetOrderById(request.OrderId);
            return order;
        }
    }
}
