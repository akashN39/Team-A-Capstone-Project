﻿using MediatR;
using Order_API.Command;
using Order_API.ExceptionHandling;
using Order_API.Interface;
using Order_API.Models;
using Order_API.Service;

namespace Order_API.Handlers
{
    // Handler
    public class UpdateOrderStatusCommandHandler : IRequestHandler<UpdateOrderStatusCommand>
    {
        private readonly IOrders _orderService;

        public UpdateOrderStatusCommandHandler(IOrders orderService)
        {
            _orderService = orderService;
        }

        public async Task<Unit> Handle(UpdateOrderStatusCommand request, CancellationToken cancellationToken)
        {
            var order = await _orderService.GetOrderByIdAsync(request.Id);

            if (order == null)
            {
                throw new NotFoundException(nameof(Order), request.Id);
            }

            await _orderService.UpdateOrderStatusAsync(order, request.OrderStatusUpdateDto);

            return Unit.Value;
        }
    }
}
