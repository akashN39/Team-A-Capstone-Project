﻿using MediatR;
using Order_API.Command;
using Order_API.Interface;
using Order_API.Service;

namespace Order_API.Handlers
{
    public class RemoveOrderCommandHandler : IRequestHandler<RemoveOrderCommand, bool>
    {
        private readonly IOrders _orderService;

        public RemoveOrderCommandHandler(IOrders orderService)
        {
            _orderService = orderService;
        }

        public async Task<bool> Handle(RemoveOrderCommand request, CancellationToken cancellationToken)
        {
            var result = await _orderService.RemoveOrderAsync(request.OrderId);
            return result;
        }
    }
}
