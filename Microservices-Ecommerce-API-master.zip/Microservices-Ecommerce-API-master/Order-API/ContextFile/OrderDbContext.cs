﻿using Microsoft.EntityFrameworkCore;
using Order_API.Models;

namespace Order_API.ContextFile
{
    public class OrderDbContext : DbContext
    {

        public OrderDbContext(DbContextOptions<OrderDbContext> options) : base(options)
        {
        }

        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

       

    }
}
