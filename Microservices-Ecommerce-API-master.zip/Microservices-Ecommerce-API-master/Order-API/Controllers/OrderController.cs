﻿using Microsoft.AspNetCore.Mvc;
using Order_API.ContextFile;
using Order_API.DTO;
using Order_API.Models;
using Newtonsoft.Json;
using ProductDto = Order_API.DTO.ProductDto;
using Newtonsoft.Json.Serialization;
using Microsoft.AspNetCore.Cors;
using Microsoft.EntityFrameworkCore;
using Models;
using System.ComponentModel;
using Order_API.Service;
using Order_API.Interface;
using MediatR;
using Order_API.Command;
using Order_API.Query;
using Order_API.Handlers;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace Order_API.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    [EnableCors("angular")]
    public class OrderController : ControllerBase
    {


        private readonly IMediator _mediator;

        public OrderController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateOrderStatus(int id, [FromBody] OrderStatusUpdateDto orderStatusUpdateDto)
        {
            var command = new UpdateOrderStatusCommand
            {
                Id = id,
                OrderStatusUpdateDto = orderStatusUpdateDto
            };

            await _mediator.Send(command);

            return NoContent();
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
        {
            var orders = await _mediator.Send(new GetOrdersQuery());

            if (orders == null || !orders.Any())
            {
                return NotFound();
            }

            return Ok(orders);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Order>> GetOrderById(int id)
        {
            var order = await _mediator.Send(new GetOrderByIdQuery { OrderId = id });

            if (order == null)
            {
                return NotFound();
            }

            return Ok(order);
        }

        [HttpPost("{userId}")]
        public async Task<ActionResult<object>> PlaceOrder(int userId)
        {
            var orderId = await _mediator.Send(new PlaceOrderCommand { UserId = userId });

            return new
            {
                message = $"Order placed successfully for user ID {userId}",
                orderId = orderId
            };
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<bool>> RemoveOrder(int id)
        {
            var result = await _mediator.Send(new RemoveOrderCommand { OrderId = id });

            if (!result)
            {
                return NotFound();
            }

            return Ok(result);
        }

        [HttpGet("getOrders/{userId}")]
        public async Task<ActionResult<IEnumerable<Order>>> GetOrdersByUserId(int userId)
        {
            var query = new GetOrdersByUserIdQuery { UserId = userId };
            var orders = await _mediator.Send(query);

            return Ok(orders);
        }

    }

}
