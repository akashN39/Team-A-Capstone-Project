﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Order_API.DTO;

namespace Order_API.Models
{
    // OrderItem model
    public class OrderItem
    {
        [Key]
        public int OrderItemId { get; set; }

        public int OrderId { get; set; }

        public int ProductId { get; set; }

        public string ProductName { get; set; } = string.Empty;
        public string? ProductImage { get; set; }

        public string? ProductDescription { get; set; }

        public int Quantity { get; set; }

        public int Price { get; set; }
        public virtual Order Order { get; set; }
    }
}
//https://localhost:7094/api/User/2
//https://localhost:7086/api/Product/2
//https://localhost:7279/api/Cart/1
