﻿using System.ComponentModel.DataAnnotations;

namespace Order_API.Models
{

    // Order model
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; } = string.Empty;

        public string Email { get; set; }= string.Empty;

        public string City { get; set; }=string.Empty;

        public string DeliveryAddress { get; set; } = string.Empty;

        public DateTime OrderDate { get; set; }

        public int TotalAmount { get; set; }

        public string OrderStatus { get; set; }

        public virtual ICollection<OrderItem> OrderItems { get; set; }
    }
}
