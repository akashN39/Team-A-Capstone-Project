﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Order_API.ContextFile;
using Order_API.DTO;
using Order_API.Interface;
using Order_API.Models;
using Product_Category_API.ExceptionHandling;

namespace Order_API.Service
{
    public class OrderService : IOrders
    {
        private readonly OrderDbContext _dbContext;
        private readonly HttpClient _httpClient;
        public OrderService(OrderDbContext dbContext, HttpClient httpClient)
        {
            _dbContext = dbContext;
            _httpClient = httpClient;
        }
        public async Task<PlaceOrderResponseDto> PlaceOrder(PlaceOrderRequestDto request)
        {
            try
            {
                //Retrieve user information
                var user = await GetUser(request.UserId);

                // Retrieve cart information
                var cart = await GetCart(request.UserId);

                // Create order items from cart items
                var orderItems = cart.Items.Select(cartItem => new OrderItem
                {
                    ProductId = cartItem.ProductId,
                    ProductName = cartItem.ProductName,
                    ProductDescription=cartItem.ProductDescription,
                    Quantity = cartItem.Quantity,
                    Price = cartItem.Price
                }).ToList();

                // Calculate total amount
                var totalAmount = orderItems.Sum(item => item.Quantity * item.Price);

                // Create order
                var order = new Order
                {
                    UserId = request.UserId,
                    UserName = user.UserName,
                    Email = user.Email,
                    OrderDate = DateTime.Now,
                    DeliveryAddress = user.Address,
                    City = user.City,
                    TotalAmount = totalAmount,
                    OrderStatus = "Pending",
                    OrderItems = orderItems,
                };

                // Save order to database
                _dbContext.Orders.Add(order);
                await _dbContext.SaveChangesAsync();

                // Clear cart items
                cart.Items.Clear();
                await UpdateCart(cart);
                // Retrieve the newly created order from the database
                var newOrder = await _dbContext.Orders
                    .Include(o => o.OrderItems)
                    .FirstOrDefaultAsync(o => o.OrderId == order.OrderId);

                // Return success response
                var response = new PlaceOrderResponseDto
                {
                    OrderId = order.OrderId,
                    UserId = order.UserId,
                    OrderDate = order.OrderDate,
                    TotalAmount = order.TotalAmount,
                    OrderStatus = order.OrderStatus,
                    OrderItems = newOrder.OrderItems.Select(item => new OrderItemDto
                    {
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        Price = item.Price,
                        ProductName = item.ProductName
                    }).ToList()

                };
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception($"An error occurred while placing the order: {ex.Message}");
            }
        }
        public async Task<IEnumerable<Order>> GetOrders()
        {
            var orders = await _dbContext.Orders.Include(o => o.OrderItems).ToListAsync();

            if (orders == null || !orders.Any())
            {
                throw new Exception("NOT FOUND ORDERS!");
            }

            return orders;
        }

        public async Task<bool> RemoveOrderAsync(int orderId)
        {
            var order = await _dbContext.Orders.FindAsync(orderId);
            if (order == null)
            {
                return false;
            }

            _dbContext.Orders.Remove(order);

            try
            {
                await _dbContext.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateException)
            {
                // handle exception
                return false;
            }
        }

        //FOR-USER
        public async Task<UserDto> GetUser(int userId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"https://localhost:7094/api/User/{userId}");
                response.EnsureSuccessStatusCode();
                var content = await response.Content.ReadAsStringAsync();
                var user = JsonConvert.DeserializeObject<UserDto>(content);
                return user;
            }
            catch (HttpRequestException ex)
            {
                throw new ApplicationException($"An error occurred while retrieving user with ID '{userId}': {ex.Message}", ex);
            }
        }
        //FOR-CART
        public async Task<Cart> GetCart(int userId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"https://localhost:7279/api/Cart/{userId}");
                response.EnsureSuccessStatusCode();
                var content = await response.Content.ReadAsStringAsync();
                JsonSerializerSettings settings = new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                };
                var cart = JsonConvert.DeserializeObject<Cart>(content, settings);
                return cart;

            }
            catch (HttpRequestException ex)
            {
                throw new ApplicationException($"An error occurred while retrieving cart for user with ID '{userId}': {ex.Message}", ex);
            }
        }

        public async Task UpdateCart(Cart cart)
        {
            var response = await _httpClient.PutAsJsonAsync($"https://localhost:7279/api/Cart/{cart.UserId}", cart);
            response.EnsureSuccessStatusCode();
        }

        public async Task<Order> GetOrderById(int orderId)
        {
            var order = await _dbContext.Orders.Include(o => o.OrderItems)
                .SingleOrDefaultAsync(o => o.OrderId == orderId);
            return order;
        }

        public async Task UpdateOrderStatusAsync(int orderId, string orderStatus)
        {
            var order = await _dbContext.Orders.FindAsync(orderId);

            if (order == null)
            {
                throw new NotFoundException($"Order with ID {orderId} not found");
            }

            order.OrderStatus = orderStatus;
            await _dbContext.SaveChangesAsync();
        }


        public async Task<Order> GetOrderByIdAsync(int id)
        {
            return await _dbContext.Orders.FindAsync(id);
        }
        public async Task UpdateOrderStatusAsync(Order order, OrderStatusUpdateDto orderStatusUpdateDto)
        {
            order.OrderStatus = orderStatusUpdateDto.OrderStatus;
            await _dbContext.SaveChangesAsync();
        }

        public async Task<List<Order>> GetOrdersByUserId(int userId)
        {
            var orders = await _dbContext.Orders.Include(o => o.OrderItems).Where(o => o.UserId == userId).ToListAsync();

            if (orders == null || !orders.Any())
            {
                throw new Exception("NO ORDERS FOUND!");
            }

            return orders;
        }
    }
}
