﻿using Command;
using Interface;
using MediatR;

namespace Handlers
{

    public class DeleteUserCommandHandler : IRequestHandler<DeleteUserCommand, bool>
    {
        private readonly IUser _userService;

        public DeleteUserCommandHandler(IUser userService)
        {
            _userService = userService;
        }

        public async Task<bool> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
        {
            return await _userService.DeleteUserByIdAsync(request.UserId);
        }


    }
}
