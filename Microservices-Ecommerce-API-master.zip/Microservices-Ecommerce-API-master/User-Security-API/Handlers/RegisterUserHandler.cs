﻿using Command;
using DTO;
using Interface;
using MediatR;

namespace Handlers
{
    public class RegisterUserHandler : IRequestHandler<RegisterUserCommand>
    {
        private readonly IUser _userService;

        public RegisterUserHandler(IUser userService)
        {
            _userService = userService;
        }

        public async Task<Unit> Handle(RegisterUserCommand request, CancellationToken cancellationToken)
        {
            var userExists = await _userService.UserExists(request.Email);
            if (userExists)
            {
                throw new ArgumentException("User already exists.");
            }

            var userRegisterRequest = new UserRegisterRequest
            {
                UserName = request.UserName,
                Email = request.Email,
                Password = request.Password,
                ConfirmPassword = request.Password,
                City = request.City,
                Address = request.Address
            };

            await _userService.CreateUser(userRegisterRequest);
            return Unit.Value;
        }
    }

}
