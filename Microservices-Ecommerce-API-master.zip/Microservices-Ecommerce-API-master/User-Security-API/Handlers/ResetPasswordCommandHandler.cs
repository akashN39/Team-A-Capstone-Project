﻿using Command;
using Interface;
using MediatR;

namespace Handlers
{
    public class ResetPasswordCommandHandler : IRequestHandler<ResetPasswordCommand, bool>
    {
        private readonly IUser _userService;

        public ResetPasswordCommandHandler(IUser userService)
        {
            _userService = userService;
        }

        public async Task<bool> Handle(ResetPasswordCommand request, CancellationToken cancellationToken)
        {
            var result = await _userService.ResetPasswordAsync(request.Token, request.NewPassword);
            return result;
        }
    }

}
