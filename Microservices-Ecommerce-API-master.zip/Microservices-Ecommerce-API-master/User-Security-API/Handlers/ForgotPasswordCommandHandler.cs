﻿using Command;
using ExceptionMiddlewareExt;
using Interface;
using MediatR;

namespace UHandlers
{
    public class ForgotPasswordCommandHandler : IRequestHandler<ForgotPasswordCommand, Unit>
    {
        private readonly IUser _userService;

        public ForgotPasswordCommandHandler(IUser userService)
        {
            _userService = userService;
        }

        public async Task<Unit> Handle(ForgotPasswordCommand request, CancellationToken cancellationToken)
        {
            var user = await _userService.GetUserByEmailAsync(request.Email);
            if (user == null)
            {
                throw new CustomException($"User with {request.Email} may not be Registerd! ");
            }

            user.PasswordResetToken = _userService.CreateRandomToken();
            user.ResetTokenExpires = DateTime.Now.AddDays(1);
            await _userService.UpdateUserAsync(user);

            // Send email to the user with the password reset link
            //await _userService.SendPasswordResetEmailAsync(request.Email, user.PasswordResetToken);

            return Unit.Value;
        }
    }

}
