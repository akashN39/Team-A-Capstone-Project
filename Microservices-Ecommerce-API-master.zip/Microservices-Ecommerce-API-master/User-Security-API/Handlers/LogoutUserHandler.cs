﻿using Command;
using MediatR;

namespace Handlers
{
    public class UserLogoutCommandHandler : IRequestHandler<UserLogoutCommand, Unit>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserLogoutCommandHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public Task<Unit> Handle(UserLogoutCommand request, CancellationToken cancellationToken)
        {
            _httpContextAccessor.HttpContext.Response.Cookies.Delete("RefreshToken");
            return Task.FromResult(Unit.Value);
        }
    }

}
