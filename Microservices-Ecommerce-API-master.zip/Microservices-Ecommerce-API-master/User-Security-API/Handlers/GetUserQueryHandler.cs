﻿using DTO;
using ExceptionMiddlewareExt;
using Interface;
using MediatR;
using Query;

namespace Handlers
{
    public class GetUserQueryHandler : IRequestHandler<GetUserQuery, UserFetchDto>
    {
        private readonly IUser _userService;

        public GetUserQueryHandler(IUser userService)
        {
            _userService = userService;
        }

        public async Task<UserFetchDto> Handle(GetUserQuery request, CancellationToken cancellationToken)
        {
            var user = await _userService.GetUserById(request.Id);
            if (user == null)
            {
                throw new CustomException("No Users Found! ");
            }

            return new UserFetchDto
            {
                Id = user.Id,
                UserName = user.UserName,
                Email = user.Email,
                City = user.City,
                Role = user.Role,
                Address = user.Address
            };
        }
    }
}
