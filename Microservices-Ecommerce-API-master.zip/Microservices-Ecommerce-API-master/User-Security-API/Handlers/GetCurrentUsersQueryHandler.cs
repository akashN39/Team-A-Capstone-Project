﻿using DTO;
using Interface;
using MediatR;
using Models;
using Query;

namespace Handlers
{
    public class GetUsersQueryHandler : IRequestHandler<GetUsersQuery, List<UserFetchDto>>
    {
        private readonly IUser _userService;

        public GetUsersQueryHandler(IUser userService)
        {
            _userService = userService;
        }

        public async Task<List<UserFetchDto>> Handle(GetUsersQuery request, CancellationToken cancellationToken)
        {
            var users =  _userService.getUsers();
            return users.Select(u => new UserFetchDto
            {
                Id = u.Id,
                UserName = u.UserName,
                Email = u.Email,
                City = u.City,
                Role = u.Role,
                Address = u.Address
            }).ToList();
        }
    }


}
