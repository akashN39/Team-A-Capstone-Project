﻿using Command;
using DTO;
using Interface;
using MediatR;

namespace Handlers
{
    public class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand, UpdateUserResponseDto>
    {
        private readonly IUser _userService;

        public UpdateUserCommandHandler(IUser userService)
        {
            _userService = userService;
        }

        public async Task<UpdateUserResponseDto> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var response = await _userService.UpdateUserAsync(request.Id, request.UpdateUserDto);
            return response;
        }
    }

}
