﻿using Command;
using ExceptionMiddlewareExt;
using Interface;
using MediatR;

namespace Handlers
{
    // Login command handler
    public class LoginCommandHandler : IRequestHandler<LoginCommand, UserLoginResponse>
    {
        private readonly IUser _userService;

        public LoginCommandHandler(IUser userService)
        {
            _userService = userService;
        }

        public async Task<UserLoginResponse> Handle(LoginCommand request, CancellationToken cancellationToken)
        {
            var user = await _userService.GetUsersByEmailwithRefreshAsync(request.Email);
            if (user == null)
            {
                throw new CustomException($"User with {request.Email}, Not Found! ");
            }
            if (!(_userService.VerifyPasswordHash(request.Password, user.PasswordHash, user.PasswordSalt)))
            {
                throw new CustomException("Password is Incorrect!");
            }

            var (accessToken, refreshToken) = _userService.CreateToken(user);
            var response = new UserLoginResponse
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken,
                Code = user.Id,
                UserRole = user.Role
            };
            return response;
        }
    }
}
