﻿using Microsoft.Extensions.FileSystemGlobbing;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{

    [Table("UsersInfo")]
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Email { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string? Profile { get; set; }
        public string? Role { get; set; }
        public string? City { get; set; }
        public string? Address { get; set; }
        //I recommend storing the password hash and salt in the database rather than using the 
        //[NotMapped] attribute, as this will ensure that the password is properly secured and can be 
        //verified when a user logs in.
        public byte[] PasswordHash { get; set; } = new byte[32];
        public byte[] PasswordSalt { get; set; } = new byte[32];
        [NotMapped]
        public string? VerificationToken { get; set; }
        [NotMapped]
        public DateTime? VerifiedAt { get; set; }
        public string? PasswordResetToken { get; set; }
        [NotMapped]
        public DateTime? ResetTokenExpires { get; set; }
        //changed
        public RefreshToken refreshToken { get; set; }

    }
}
