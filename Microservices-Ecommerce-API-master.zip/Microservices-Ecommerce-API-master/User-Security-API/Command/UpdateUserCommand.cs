﻿using DTO;
using MediatR;

namespace Command
{
    public class UpdateUserCommand : IRequest<UpdateUserResponseDto>
    {
        public int Id { get; set; }
        public UpdateUserDto UpdateUserDto { get; set; }
    }

}
