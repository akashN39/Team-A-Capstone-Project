﻿using DTO;
using MediatR;

namespace Command
{
    public class RegisterUserCommand : IRequest
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
    }


}
