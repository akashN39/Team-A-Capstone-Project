﻿using MediatR;

namespace Command
{
    public class UserLogoutCommand : IRequest<Unit>
    {
    }
}
