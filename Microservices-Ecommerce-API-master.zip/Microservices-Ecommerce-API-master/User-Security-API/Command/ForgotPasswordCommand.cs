﻿using MediatR;
using Requests;

namespace Command
{
    public class ForgotPasswordCommand : IRequest<Unit>
    {
        public string Email { get; set; }
    }
}
