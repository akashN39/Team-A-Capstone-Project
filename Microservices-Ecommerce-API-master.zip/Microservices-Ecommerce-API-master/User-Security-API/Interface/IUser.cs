﻿using DTO;
using Models;

namespace Interface
{
    public interface IUser
    {
        public List<UserFetchDto> getUsers();
        public void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt);
        public string CreateRandomToken();
        public bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt);
        public (string accessToken, string refreshToken) CreateToken(User user);

        public Task<bool> UserExists(string email);
        public Task<User> CreateUser(UserRegisterRequest request);

        public Task<User> GetUserByEmailAsync(string email);
        public Task<UserFetchDto> GetUserById(int id);

        //Task UpdateUserAsync(User user);
        public Task<bool> ResetPasswordAsync(string token, string password);

        public Task<User> GetUserByResetTokenAsync(string token);

        public Task<bool> UpdateUserAsync(User user);

        public Task<bool> SendPasswordResetEmailAsync(string email, string token);

        public Task<User> GetUsersByEmailwithRefreshAsync(string email);

        Task<bool> DeleteUserByIdAsync(int id);

        public Task<UpdateUserResponseDto> UpdateUserAsync(int id, UpdateUserDto updateUserDto);
    }
}
