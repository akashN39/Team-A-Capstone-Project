﻿using AutoMapper;
using Data;
using DTO;
using ExceptionHandling;
using MailKit.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MimeKit;
using Models;
using Org.BouncyCastle.Asn1.Ocsp;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace Interface
{
    public class UserService : IUser
    {
        private readonly DataContext _context;
        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;

        public UserService(DataContext context, IConfiguration configuration, IMapper mapper)
        {
            _context = context;
            _configuration = configuration;
            _mapper = mapper;
        }


        public string CreateRandomToken()
        {
            // Generate a random 8-digit hex string
            byte[] randomBytes = new byte[4];
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomBytes);
            }
            string hexString = BitConverter.ToString(randomBytes).Replace("-", string.Empty);

            // Output the hex string
            return hexString;
        }

        public (string accessToken, string refreshToken) CreateToken(User user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Token"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
            new Claim(JwtRegisteredClaimNames.Name, user.UserName),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim(JwtRegisteredClaimNames.Aud, _configuration["Jwt:Audience"]),
            new Claim(JwtRegisteredClaimNames.Iss, _configuration["Jwt:Issuer"])
        };

            var accessToken = new JwtSecurityToken(
                issuer: _configuration["Issuer"],
                audience: _configuration["Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(20),
                signingCredentials: credentials
                );
            var refreshToken = new RefreshToken
            {
                Token = Guid.NewGuid().ToString(),
                UserId = user.Id,
                Expires = DateTime.UtcNow.AddMinutes(40)
            };

            var refreshTokenValue = new JwtSecurityTokenHandler().WriteToken(new JwtSecurityToken(
            expires: refreshToken.Expires,
                    signingCredentials: credentials
            ));

            user.refreshToken = refreshToken;

            _context.RefreshTokens.Add(refreshToken);

            _context.Users.Update(user);

            _context.SaveChanges();
            return (new JwtSecurityTokenHandler().WriteToken(accessToken), refreshTokenValue);
        }

        public void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac
                    .ComputeHash(Encoding.UTF8.GetBytes(password));
            }
        }
        public async Task<User> CreateUser(UserRegisterRequest request)
        {
            CreatePasswordHash(request.Password, out byte[] passwordHash, out byte[] passwordSalt);

            var user = new User
            {
                UserName = request.UserName,
                Email = request.Email,
                PasswordHash = passwordHash,
                PasswordSalt = passwordSalt,
                VerificationToken = CreateRandomToken(),
                Role = "User",
                Address = request.Address,
                City = request.City,
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return user;
        }
        public bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512(passwordSalt))
            {
                var computedHash = hmac
                    .ComputeHash(Encoding.UTF8.GetBytes(password));
                return computedHash.SequenceEqual(passwordHash);
            }
        }

        public async Task<User> GetUserByEmailAsync(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }
        public List<UserFetchDto> getUsers()
        {
            return _context.Users.Select(x => _mapper.Map<UserFetchDto>(x)).ToList();
        }

        public async Task<bool> UserExists(string email)
        {
            return await _context.Users.AnyAsync(u => u.Email == email);
        }


        public async Task<User> GetUserByResetTokenAsync(string token)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.PasswordResetToken == token);
        }
        public async Task<bool> ResetPasswordAsync(string token, string password)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.PasswordResetToken == token);
            if (user == null || user.ResetTokenExpires < DateTime.Now) return false;

            CreatePasswordHash(password, out byte[] passwordHash, out byte[] passwordSalt);

            user.PasswordHash = passwordHash;
            user.PasswordSalt = passwordSalt;
            user.PasswordResetToken = null;
            user.ResetTokenExpires = null;

            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UpdateUserAsync(User user)
        {
            _context.Users.Update(user);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> SendPasswordResetEmailAsync(string email, string resetToken)
        {
            var user = await GetUserByEmailAsync(email);

            if (user == null)
            {
                throw new ArgumentException("User not found", nameof(email));
            }
            //say our mail:jack@example.com
            //Subject: Password Reset
            //From: Mya Pfannerstill<mya.pfannerstill @ethereal.email>
            //To: jack < jack@example.com >
            //Time: Today at 23:40
            //Message - ID: < 5W89EOXTFJU4.8MNKX7LD203A3 @in3242123w2>
            //Hello jack,

            //Please use the following token to reset your password: 97151991

            //This token will expire in 24 hours.

            //Regards,
            //Your Email

            var message = new MimeMessage();
            //add from account we get from ethereal account(our -dummy mail)!.[Change below both]
            message.From.Add(new MailboxAddress("Randi Pouros", "randi.pouros@ethereal.email"));
            message.To.Add(new MailboxAddress(user.UserName, user.Email));
            message.Subject = "Password Reset";
            message.Body = new TextPart("plain")
            {
                Text = $"Hello {user.UserName},\n\n" +
                       $"Please use the following token to reset your password: {resetToken}\n\n" +
                       $"This token will expire in 24 hours.\n\n" +
                       $"Regards,\n" +
                       $"Your Email"
            };
            using (var client = new MailKit.Net.Smtp.SmtpClient())
            {
                client.Connect("smtp.ethereal.email", 587, SecureSocketOptions.StartTls); //usual socket
                //[our mail..
                client.Authenticate("randi.pouros@ethereal.email", "zGQeEuyZFbcPBn7h9V"); //from email,password
                client.Send(message);
                client.Disconnect(true);
            }

            return true;

        }

        public async Task<User> GetUsersByEmailwithRefreshAsync(string email)
        {
            var something = await _context.Users
             .Include(u => u.refreshToken).FirstOrDefaultAsync(u => u.Email == email);
            return something;
        }


        public async Task<UpdateUserResponseDto> UpdateUserAsync(int id, UpdateUserDto updateUserDto)
        {
            var user = await _context.Users.FindAsync(id);

            if (user == null)
            {
                throw new NotFoundException("User not found");
            }

            user.UserName= updateUserDto.UserName;
            user.Email = updateUserDto.Email;
            user.Role = updateUserDto.Role;
            user.City = updateUserDto.City;
            user.Address = updateUserDto.Address;

            _context.Users.Update(user);
            await _context.SaveChangesAsync();

            return new UpdateUserResponseDto
            {
                Message = "User Updated successfully."
            };
        }
        public async Task<UserFetchDto> GetUserById(int id)
        {
            var user = _context.Users.FirstOrDefault(x => x.Id == id);
            return _mapper.Map<UserFetchDto>(user);
        }

        public async Task<bool> DeleteUserByIdAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);

            if (user == null)
            {
                return false;
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}
