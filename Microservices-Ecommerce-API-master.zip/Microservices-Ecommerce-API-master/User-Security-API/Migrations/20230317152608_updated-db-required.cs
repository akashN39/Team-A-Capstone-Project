﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace VerifyEmailForgotPasswordDetail.Migrations
{
    public partial class updateddbrequired : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PasswordHash",
                table: "UsersInfo");

            migrationBuilder.DropColumn(
                name: "PasswordSalt",
                table: "UsersInfo");

            migrationBuilder.DropColumn(
                name: "ResetTokenExpires",
                table: "UsersInfo");

            migrationBuilder.DropColumn(
                name: "VerifiedAt",
                table: "UsersInfo");

            migrationBuilder.DropColumn(
                name: "Token",
                table: "RefreshTokens");

            migrationBuilder.RenameColumn(
                name: "VerificationToken",
                table: "UsersInfo",
                newName: "Profile");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Profile",
                table: "UsersInfo",
                newName: "VerificationToken");

            migrationBuilder.AddColumn<byte[]>(
                name: "PasswordHash",
                table: "UsersInfo",
                type: "varbinary(max)",
                nullable: false,
                defaultValue: new byte[0]);

            migrationBuilder.AddColumn<byte[]>(
                name: "PasswordSalt",
                table: "UsersInfo",
                type: "varbinary(max)",
                nullable: false,
                defaultValue: new byte[0]);

            migrationBuilder.AddColumn<DateTime>(
                name: "ResetTokenExpires",
                table: "UsersInfo",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "VerifiedAt",
                table: "UsersInfo",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Token",
                table: "RefreshTokens",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
