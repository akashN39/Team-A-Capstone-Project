﻿using DTO;
using MediatR;

namespace Query
{
    public class GetUserQuery : IRequest<UserFetchDto>
    {
        public int Id { get; set; }
    }

}
