﻿using DTO;
using MediatR;
using Models;

namespace Query
{
    public class GetUsersQuery : IRequest<List<UserFetchDto>>
    {
    }

}
