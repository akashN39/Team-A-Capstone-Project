﻿namespace DTO
{
    public class UpdateUserResponseDto
    {
        public string Message { get; set; }
    }
}
