﻿using System.ComponentModel.DataAnnotations;

namespace DTO
{
    public class UpdateUserDto
    {
        public string UserName { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Role { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
    }
}
