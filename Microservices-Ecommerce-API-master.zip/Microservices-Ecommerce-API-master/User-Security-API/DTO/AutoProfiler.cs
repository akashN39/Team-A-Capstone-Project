﻿using AutoMapper;
using Models;

namespace DTO
{
    public class AutoMapperProfiler:Profile
    {
        public AutoMapperProfiler()
        {
            CreateMap<User,UserFetchDto>();
        }
    }
}
