﻿using Command;
using DTO;
using ExceptionMiddlewareExt;
using Interface;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Query;
using Requests;

namespace VerifyEmailForgotPasswordTutorial.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("angular")]

    public class UserController : ControllerBase
    {

        //private readonly IUser _userService;
        private readonly IMediator _mediator;

        public UserController( IMediator mediator)
        {
            _mediator = mediator;
        }

        //[HttpPost("register")]
        //public async Task<IActionResult> Register(UserRegisterRequest request)
        //{
        //    if (await _userService.UserExists(request.Email))
        //    {
        //        return StatusCode(400,new { Message = "User already exists." });
        //    }
        //    await _userService.CreateUser(request);
        //    return Ok(new { message = "User successfully created!" });
        //}


        [HttpPost("register")]
        public async Task<IActionResult> Register(UserRegisterRequest request)
        {
            var command = new RegisterUserCommand
            {
                UserName = request.UserName,
                Email = request.Email,
                Password = request.Password,
                City = request.City,
                Address = request.Address
            };

            try
            {
                await _mediator.Send(command);
            }
            catch (ArgumentException ex)
            {
                return StatusCode(400, new { Message = ex.Message });
            }

            return Ok(new { message = "User successfully created!" });
        }

        //[AllowAnonymous]
        //[HttpPost("login")]
        //public async Task<IActionResult> Login(UserLoginRequest request)
        //{
        //    var user = await _userService.GetUsersByEmailwithRefreshAsync(request.Email);
        //    if (user == null)
        //    {
        //        return StatusCode(400,new {Message="User not found."});
        //    }
        //    if (!(_userService.VerifyPasswordHash(request.Password, user.PasswordHash, user.PasswordSalt)))
        //    {
        //        return StatusCode(400,new { Message = "Password is incorrect." });
        //    }

        //    var (accessToken, refreshToken) = _userService.CreateToken(user);
        //    var response = new
        //    {
        //        AccessToken = accessToken,
        //        //RefreshToken = refreshToken,
        //        Code=user.Id,
        //        UserRole = user.Role // include user role in response
        //    };
        //    Response.Cookies.Append("RefreshToken", refreshToken, new CookieOptions
        //    {
        //        HttpOnly = true,
        //        Expires = DateTime.UtcNow.AddMinutes(10),
        //        SameSite = SameSiteMode.None,
        //        Secure = true
        //    });


        //    //not-mandatory-to-return-refreshToken...it will be in cookies..anyway}
        //    return Ok(new { response });

        //    //return Ok($"Welcome back, {user.Email}! :)");
        //}

        // Updated Login method in controller

        [HttpPost("login")]
        public async Task<IActionResult> Login(UserLoginRequest request)
        {
            var command = new LoginCommand
            {
                Email = request.Email,
                Password = request.Password
            };
            var response = await _mediator.Send(command);

            Response.Cookies.Append("RefreshToken", response.RefreshToken, new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddMinutes(10),
                SameSite = SameSiteMode.None,
                Secure = true
            });

            return Ok(response);
        }


        //[AllowAnonymous]
        //[HttpPost("logout")]
        //public async Task<IActionResult> Logout()
        //{
        //    Response.Cookies.Delete("RefreshToken");

        //    // You could also clear the access token here, but it's not strictly necessary
        //    // as the access token will become invalid when it expires

        //    return Ok();
        //}

        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            await _mediator.Send(new UserLogoutCommand());
            return Ok();
        }

        //[HttpPost("forgot-password/{email}")]
        //public async Task<IActionResult> ForgotPassword(string email)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    var user = await _userService.GetUserByEmailAsync(email);
        //    if (user == null)
        //    {
        //        return StatusCode(400,new { message = "User not found." });
        //    }

        //    user.PasswordResetToken = _userService.CreateRandomToken();
        //    user.ResetTokenExpires = DateTime.Now.AddDays(1);
        //    await _userService.UpdateUserAsync(user);


        //    // Send email to the user with the password reset link
        //    //remember to generate ethereal-dummy account for you! each time!

        //    //await _userService.SendPasswordResetEmailAsync(email,user.PasswordResetToken);

        //    return Ok(new {message= "A password reset token has been sent to your email." });

        //    //return Ok("You may now reset your password.");
        //}


        [HttpPost("forgot-password/{email}")]
        public async Task<IActionResult> ForgotPassword(string email, [FromServices] IMediator mediator)
        {

            var command = new ForgotPasswordCommand { Email = email };
            await mediator.Send(command);
            return Ok(new { message = "A password reset token has been sent to your email." });

        }



        //[HttpPost("reset-password")]
        //public async Task<IActionResult> ResettPassword(ResetPasswordRequest request)
        //{
        //    var result = await _userService.ResetPasswordAsync(request.Token, request.Password);
        //    if (!result)
        //    {
        //        return BadRequest(new { message = "Invalid Token." });
        //    }
        //    return Ok(new { Message = "Password successfully reset." });
        //}




        //[HttpGet, Authorize(Roles = "Admin")]

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword(ResetPasswordRequest request)
        {
            var command = new ResetPasswordCommand
            {
                Token = request.Token,
                NewPassword = request.Password
            };

            var result = await _mediator.Send(command);

            if (!result)
            {
                return BadRequest(new { message = "Invalid Token." });
            }

            return Ok(new { message = "Password successfully reset." });
        }


        //[HttpGet]
        //public IActionResult getCurreUser()
        //{
        //    var allUsers = _userService.getUsers();
        //    return Ok(allUsers);
        //}


        [HttpGet]
        public async Task<IActionResult> getCurreUser()
        {
            var query = new GetUsersQuery();
            var result = await _mediator.Send(query);
            return Ok(result);
        }

        //[HttpGet("{id}")]
        //public async Task<IActionResult> GetUser(int id)
        //{
        //    var user = await _userService.GetUserById(id);
        //    if (user == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(user);
        //}

        //SO REMOVING USER BY ANYONE IS UNAUTHORIZED
        //SO FIRST 401-UNAUTHORIZED..SO FIRST AUTHORIZE..
        //IF NOT VALID USER 403-FORBIDDEN!
        //LOGIN->CHECK->TOKEN IN JWT.IO
        //IF ROLE THERE AUTHORIZE WITH TOKEN ALREADY PROVIDED
        //THEN CAN REMOVE USER

        [HttpGet("{id}")]
        public async Task<IActionResult> GetUser(int id)
        {
            var query = new GetUserQuery { Id = id };
            var result = await _mediator.Send(query);

            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }



        //[HttpDelete("{id}")]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    var result = await _userService.DeleteUserByIdAsync(id);

        //    if (!result)
        //    {
        //        return NotFound(new { Message = "No User Found!" });
        //    }
        //    return Ok(new { message = "User deleted successfully." });
        //}


        //USER-UPDATE-ONLY-FEW-DETAILS

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var command = new DeleteUserCommand { UserId = id };
            var result = await _mediator.Send(command);

            if (!result)
            {
                return NotFound(new { Message = "No User Found!" });
            }
            return Ok(new { message = "User deleted successfully." });
        }

        //[HttpPut("{id}")]
        //public async Task<ActionResult<UpdateUserResponseDto>> UpdateUser(int id, UpdateUserDto updateUserDto)
        //{
        //    var response = await _userService.UpdateUserAsync(id, updateUserDto);
        //    return Ok(response);
        //}

        [HttpPut("{id}")]
        public async Task<ActionResult<UpdateUserResponseDto>> UpdateUser(int id, UpdateUserDto updateUserDto)
        {
            var response = await _mediator.Send(new UpdateUserCommand { Id = id, UpdateUserDto = updateUserDto });
            return Ok(response);
        }

    }
}






