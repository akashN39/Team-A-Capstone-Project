﻿

using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Product_Category_API.Command;
using Product_Category_API.Controllers;
using Product_Category_API.Models;
using Product_Category_API.Query;
using Xunit;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace TestServices_API
{
    [TestClass]
    public class ProductControllerTests
    {
        private Mock<IMediator> _mediatorMock;
        private ProductController _controller;

        [TestInitialize]
        public void Setup()
        {
            _mediatorMock = new Mock<IMediator>();
            _controller = new ProductController(_mediatorMock.Object);
        }
        //working-product-getproductbyId
        [Fact]
        public async Task GetProductById_Returns()
        {
            // Arrange
            var productId = 1;
            var product = new Product { ProductId = productId, ProductName = "Product 1" };
            _mediatorMock.Setup(m => m.Send(It.IsAny<GetProductByIdQuery>(), default(CancellationToken)))
                .ReturnsAsync(product);

            // Act
            var result = await _controller.GetProductById(productId);

            // Assert
            Assert.IsInstanceOfType(result, typeof(ObjectResult));
            var objectResult = (ObjectResult)result;
            Assert.AreEqual(objectResult.StatusCode, 200);
            var value = (Product)objectResult.Value;
            Assert.AreEqual(product, value);
        }
        //working getallproducts
        [Fact]
        public async Task GetAllProducts_Returns()
        {
            // Arrange
            var products = new List<Product>
        {
            new Product { ProductId = 1, ProductName = "Product 1" },
            new Product { ProductId = 2, ProductName = "Product 2" },
            new Product { ProductId = 3, ProductName = "Product 3" }
        };
            _mediatorMock.Setup(m => m.Send(It.IsAny<GetAllProductsQuery>(), default(CancellationToken)))
                .ReturnsAsync(products);

            // Act
            var result = await _controller.GetAllProducts();

            // Assert
            Assert.IsInstanceOfType(result, typeof(ObjectResult));
            var objectResult = (ObjectResult)result;
            Assert.AreEqual(objectResult.StatusCode, 200);
            var value = (List<Product>)objectResult.Value;
            CollectionAssert.AreEqual(products, value);
        }



     

        //CreateProductWorking
        [Fact]
        public async Task CreateProduct_Returns_CreatedAtR()
        {
            // Arrange
            var product = new Product { ProductName = "Product 1" };
            var createCommand = new CreateProductCommand(product);
            var createdProduct = new Product { ProductId = 1, ProductName = "Product 1" };
            _mediatorMock.Setup(m => m.Send(createCommand, default(CancellationToken)))
                .ReturnsAsync(createdProduct);

            // Act
            var result = await _controller.CreateProduct(createCommand);

            // Assert
            Assert.IsInstanceOfType(result, typeof(ObjectResult));
            var objectResult = (ObjectResult)result;
            Assert.AreEqual(201, objectResult.StatusCode);
            Assert.AreEqual(createdProduct, objectResult.Value);
        }


       





    }

}

