﻿namespace Product_Category_API.ExceptionHandling
{
    public class NotFoundException : Exception
    {
        public NotFoundException(string message):base(message)
        {
        }
    }
}
