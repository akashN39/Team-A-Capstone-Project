﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Product_Category_API.Command;
using Product_Category_API.ContextFile;
using Product_Category_API.ExceptionHandling;
using Product_Category_API.Interface;
using Product_Category_API.Models;
using Product_Category_API.Query;
using Product_Category_API.Repository;


namespace Product_Category_API.Controllers
{
    [EnableCors("angular")]
    [ApiController]
    [Route("api/[controller]")]

    public class ProductController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ProductController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var query = new GetAllProductsQuery();
            var products = await _mediator.Send(query);
            return StatusCode(200, products );
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            var query = new GetProductByIdQuery(id);
            var product = await _mediator.Send(query);
            if (product == null)
            {
                return StatusCode(404, new { message = $"Product with ID {id} not found." });
            }
            return StatusCode(200,   product );
        }

        [HttpPost]
        public async Task<IActionResult> CreateProduct(CreateProductCommand command)
        {
            var product = await _mediator.Send(command);
            return StatusCode(201,  product );
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, UpdateProductCommand command)
        {
            if (id != command.Product.ProductId)
            {
                return StatusCode(400, new { message = "Product ID does not match the request body." });
            }

            try
            {
                await _mediator.Send(command);
            }
            catch (NotFoundException ex)
            {
                return StatusCode(404, new { message = ex.Message });
            }

            return StatusCode(204);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var command = new DeleteProductCommand(id);

            try
            {
                await _mediator.Send(command);
            }
            catch (NotFoundException ex)
            {
                return StatusCode(404, new { message = ex.Message });
            }

            return StatusCode(204, new { message = $"Product with Id:{id} Deleted Successfully!" });
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadProductsFile(IFormFile file, [FromServices] IMediator mediator)
        {
            if (file == null || file.Length == 0)
            {
                return StatusCode(400, new { message = "No file selected." });
            }
            if (!Path.GetExtension(file.FileName).Equals(".csv", StringComparison.OrdinalIgnoreCase))
            {
                return StatusCode(400, new { message = "Invalid file type." });
            }

            var filePath = Path.GetTempFileName();
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var command = new UploadProductsCommand(filePath);
            var rowsAffected = await mediator.Send(command);

            return StatusCode(200, new { message = $"{rowsAffected} products uploaded successfully." });
        }


        [HttpPost]
        [Route("/{productId:int}/upload-image")]
        public async Task<IActionResult> UploadImage([FromRoute] int productId, IFormFile profileImage)
        {
            var command = new UploadImageCommand
            {
                ProductId = productId,
                ProfileImage = profileImage
            };

            var result = await _mediator.Send(command);

            return result ? Ok(new { Message = "Image uploaded successfully" }) : StatusCode(StatusCodes.Status500InternalServerError,
               new { Message = "Error uploading image" });
        }

    }
}
