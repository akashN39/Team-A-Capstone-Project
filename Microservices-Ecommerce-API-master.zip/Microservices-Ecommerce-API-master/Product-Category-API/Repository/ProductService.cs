﻿using CsvHelper;
using Microsoft.EntityFrameworkCore;
using Product_Category_API.ContextFile;
using Product_Category_API.ExceptionHandling;
using Product_Category_API.Interface;
using Product_Category_API.Models;

namespace Product_Category_API.Repository
{
    public class ProductService : IProduct
    {
        private readonly capsdbContext _dbContext;

        public ProductService(capsdbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<Product>> GetAllProductsAsync()
        {
            return await _dbContext.Products.Include(x => x.Category).ToListAsync();
        }

        public async Task<Product> GetProductByIdAsync(int id)
        {
            var product=await _dbContext.Products.Include(x=>x.Category).FirstOrDefaultAsync(p => p.ProductId == id);

            if (product == null)
            {
                throw new NotFoundException($"No product with ID '{id}' exists in the database.");
            }

            return product;
        }

        public async Task AddProductAsync(Product product)
        {
            if (product == null)
            {
                throw new ArgumentNullException(nameof(product));
            }
            _dbContext.Products.Add(product);
            await _dbContext.SaveChangesAsync();
        }
        public async Task UpdateProductAsync(Product product)
        {
            if (product == null)
            {
                throw new ArgumentNullException(nameof(product));
            }
            _dbContext.Entry(product).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteProductAsync(Product product)
        {
            if (product == null)
            {
                throw new ArgumentNullException(nameof(product));
            }
            _dbContext.Products.Remove(product);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<int> AddProductsBunchAsync(List<Product> products)
        {
            if (products == null || !products.Any())
            {
                throw new ArgumentNullException(nameof(products));
            }
            try
            {
                _dbContext.Products.AddRange(products);
                return await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"An error occurred while saving the products: {ex.Message}", ex);
            }
        }
        public async Task<bool> UpdateProfileImage(int productId, string profileImageUrl)
        {
            var product = await GetProductByIdAsync(productId);

            if (product != null)
            {
                product.ProductImage = profileImageUrl;
                await _dbContext.SaveChangesAsync();
                return true;
            }

            return false;
        }

        public async Task<string> Upload(IFormFile file, string fileName)
        {
            if (file == null)
            {
                throw new ArgumentNullException(nameof(file));
            }
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), @"Resources\Images", fileName);
            using Stream fileStream = new FileStream(filePath, FileMode.Create);
            await file.CopyToAsync(fileStream);
            return GetServerRelativePath(fileName);
        }

        private string GetServerRelativePath(string fileName)
        {
            return Path.Combine(@"Resources\Images", fileName);
        }
        public async Task<bool> Exists(int productId)
        {
            return await _dbContext.Products.AnyAsync(x => x.ProductId == productId);
        }
    }
}
