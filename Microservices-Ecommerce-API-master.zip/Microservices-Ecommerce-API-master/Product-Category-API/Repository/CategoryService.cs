﻿using Microsoft.EntityFrameworkCore;
using Product_Category_API.ContextFile;
using Product_Category_API.Interface;
using Product_Category_API.Models;

namespace Product_Category_API.Repository
{
    public class CategoryService : ICategory
    {
        private readonly capsdbContext _dbContext;

        public CategoryService(capsdbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<Category>> GetAllCategoriesAsync()
        {
            try
            {
                return await _dbContext.Categories.ToListAsync();
            }
            catch (Exception ex)
            {
                throw new ApplicationException("An error occurred while retrieving categories.", ex);
            }
        }

        public async Task<Category> GetCategoryByIdAsync(int id)
        {
            try
            {
                var category = await _dbContext.Categories.FirstOrDefaultAsync(c => c.CategoryId == id);

                if (category == null)
                {
                    throw new ArgumentException($"No category with ID '{id}' exists in the database.");
                }

                return category;
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"An error occurred while retrieving category with ID '{id}'.", ex);
            }
        }

        public async Task AddCategoryAsync(Category category)
        {
            try
            {
                _dbContext.Categories.Add(category);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new ApplicationException("An error occurred while adding the category.", ex);
            }
        }

        public async Task UpdateCategoryAsync(Category category)
        {
            try
            {
                _dbContext.Entry(category).State = EntityState.Modified;
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"An error occurred while updating the category with ID '{category.CategoryId}'.", ex);
            }
        }

        public async Task DeleteCategoryAsync(Category category)
        {
            try
            {
                _dbContext.Categories.Remove(category);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"An error occurred while deleting the category with ID '{category.CategoryId}'.", ex);
            }
        }
    }
}
