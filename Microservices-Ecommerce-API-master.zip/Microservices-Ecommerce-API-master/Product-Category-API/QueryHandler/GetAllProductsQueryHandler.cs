﻿using MediatR;
using Product_Category_API.Interface;
using Product_Category_API.Models;
using Product_Category_API.Query;

namespace Product_Category_API.QueryHandler
{
    public class GetAllProductsQueryHandler : IRequestHandler<GetAllProductsQuery, List<Product>>
    {
        private readonly IProduct _productService;

        public GetAllProductsQueryHandler(IProduct productService)
        {
            _productService = productService;
        }

        public async Task<List<Product>> Handle(GetAllProductsQuery query, CancellationToken cancellationToken)
        {
            return await _productService.GetAllProductsAsync();
        }
    }
}
