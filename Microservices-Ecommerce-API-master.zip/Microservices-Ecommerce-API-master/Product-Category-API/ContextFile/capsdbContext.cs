﻿using Microsoft.EntityFrameworkCore;
using Product_Category_API.Models;

namespace Product_Category_API.ContextFile
{
    public partial class capsdbContext : DbContext
    {
        public capsdbContext()
        {
        }

        public capsdbContext(DbContextOptions<capsdbContext> options)
            : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; } = null!;
        public DbSet<Product> Products { get; set; } = null!;

    }
}
