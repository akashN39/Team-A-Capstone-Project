﻿using MediatR;
using Product_Category_API.Models;

namespace Product_Category_API.Query
{
    public record GetProductByIdQuery(int ProductId) : IRequest<Product>;
}
