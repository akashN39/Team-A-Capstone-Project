﻿using MediatR;

namespace Product_Category_API.Command
{
    public record DeleteProductCommand(int ProductId) : IRequest<Unit>;
}
