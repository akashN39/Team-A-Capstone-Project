﻿using MediatR;
using Product_Category_API.Models;

namespace Product_Category_API.Command
{
    public record UploadProductsCommand(string FilePath) : IRequest<int>;
}
