﻿using MediatR;

namespace Product_Category_API.Command
{
    public class UploadImageCommand : IRequest<bool>
    {
        public int ProductId { get; set; }
        public IFormFile ProfileImage { get; set; }
    }
}
