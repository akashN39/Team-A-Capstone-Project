﻿using MediatR;
using Product_Category_API.Command;
using Product_Category_API.Interface;

namespace Product_Category_API.Handlers
{
    public class UpdateProductCommandHandler : IRequestHandler<UpdateProductCommand, Unit>
    {
        private readonly IProduct _productService;

        public UpdateProductCommandHandler(IProduct productService)
        {
            _productService = productService;
        }

        public async Task<Unit> Handle(UpdateProductCommand command, CancellationToken cancellationToken)
        {
            await _productService.UpdateProductAsync(command.Product);
            return Unit.Value;
        }
    }
}
