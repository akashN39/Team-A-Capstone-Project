﻿using MediatR;
using Product_Category_API.Command;
using Product_Category_API.ExceptionHandling;
using Product_Category_API.Interface;

namespace Product_Category_API.Handlers
{
    public class DeleteProductCommandHandler : IRequestHandler<DeleteProductCommand, Unit>
    {
        private readonly IProduct _productService;

        public DeleteProductCommandHandler(IProduct productService)
        {
            _productService = productService;
        }

        public async Task<Unit> Handle(DeleteProductCommand command, CancellationToken cancellationToken)
        {
            var product = await _productService.GetProductByIdAsync(command.ProductId);
            if (product == null)
            {
                throw new NotFoundException($"Product with ID {command.ProductId} not found.");
            }

            await _productService.DeleteProductAsync(product);
            return Unit.Value;
        }
    }

}
