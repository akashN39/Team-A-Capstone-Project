﻿using MediatR;
using Product_Category_API.Command;
using Product_Category_API.Interface;
using Product_Category_API.Models;

namespace Product_Category_API.Handlers
{
    public class CreateProductCommandHandler : IRequestHandler<CreateProductCommand, Product>
    {
        private readonly IProduct _productService;

        public CreateProductCommandHandler(IProduct productService)
        {
            _productService = productService;
        }

        public async Task<Product> Handle(CreateProductCommand command, CancellationToken cancellationToken)
        {
            await _productService.AddProductAsync(command.Product);
            return command.Product;
        }
    }
}
