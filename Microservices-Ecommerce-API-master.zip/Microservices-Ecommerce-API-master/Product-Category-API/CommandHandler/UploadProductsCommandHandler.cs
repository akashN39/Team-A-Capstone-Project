﻿using MediatR;
using Product_Category_API.Command;
using Product_Category_API.Interface;
using Product_Category_API.Models;
using Product_Category_API.Repository;


namespace Product_Category_API.Handlers
{
    public class UploadProductsCommandHandler : IRequestHandler<UploadProductsCommand, int>
    {
        private readonly IProduct _productService;

        public UploadProductsCommandHandler(IProduct productService)
        {
            _productService = productService;
        }

        public async Task<int> Handle(UploadProductsCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var products = await ReadProductsFromCsvAsync(request.FilePath);
                return await _productService.AddProductsBunchAsync(products);
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"An error occurred while uploading the file: {ex.Message}", ex);
            }
        }

        private async Task<List<Product>> ReadProductsFromCsvAsync(string filePath)
        {
            using var streamReader = new StreamReader(filePath);
            var products = new List<Product>();
            var headers = await streamReader.ReadLineAsync(); // assuming the first line is header
            while (!streamReader.EndOfStream)
            {
                var line = await streamReader.ReadLineAsync();
                var values = line.Split(',');
                if (values.Length != 6) // assuming the CSV has 6 columns: ProductName, ProductDescription, ProductPrice, ProductQuantity, ProductImage, CategoryId
                {
                    continue; // skip invalid rows
                }
                var product = new Product
                {
                    ProductName = values[0],
                    ProductDescription = values[1],
                    ProductPrice = int.Parse(values[2]),
                    ProductQuantity = values[3],
                    ProductImage = values[4],
                    CategoryId = int.Parse(values[5])
                };
                products.Add(product);
            }
            return products;
        }
    }
}
