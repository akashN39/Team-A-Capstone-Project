﻿using MediatR;
using Product_Category_API.Command;
using Product_Category_API.Interface;
using Product_Category_API.Repository;

namespace Product_Category_API.CommandHandler
{
    public class UploadImageCommandHandler : IRequestHandler<UploadImageCommand, bool>
    {
        private readonly IProduct _productService;

        public UploadImageCommandHandler(IProduct productService)
        {
            _productService = productService;
        }

        public async Task<bool> Handle(UploadImageCommand request, CancellationToken cancellationToken)
        {
            var validExtensions = new List<string>
        {
            ".jpeg",
            ".png",
            ".gif",
            ".jpg"
        };

            if (request.ProfileImage != null && request.ProfileImage.Length > 0)
            {
                var extension = Path.GetExtension(request.ProfileImage.FileName);
                if (validExtensions.Contains(extension))
                {
                    if (await _productService.Exists(request.ProductId))
                    {
                        var fileName = Guid.NewGuid() + Path.GetExtension(request.ProfileImage.FileName);

                        var fileImagePath = await _productService.Upload(request.ProfileImage, fileName);

                        if (await _productService.UpdateProfileImage(request.ProductId, fileImagePath))
                        {
                            return true;
                        }

                        throw new Exception("Error uploading image");
                    }
                }

                throw new ArgumentException("This is not a valid Image format");
            }

            throw new ArgumentException("Please Check the ID and ImageFormat!");
        }
    }
}
