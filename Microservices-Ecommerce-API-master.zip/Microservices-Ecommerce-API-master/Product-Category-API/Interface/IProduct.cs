﻿using Product_Category_API.Models;

namespace Product_Category_API.Interface
{
    public interface IProduct
    {
        Task<List<Product>> GetAllProductsAsync();
        Task<Product> GetProductByIdAsync(int id);
        Task AddProductAsync(Product product);
        Task UpdateProductAsync(Product product);
        Task DeleteProductAsync(Product product);
        Task<int> AddProductsBunchAsync(List<Product> products);
        Task<bool> UpdateProfileImage(int productId, string profileImageUrl);

        Task<string> Upload(IFormFile file, string fileName);
        Task<bool> Exists(int productId);
    }
}
